<#
    .SYNOPSIS
        Creates a log entry in the log file and outputs it on the screen
    .DESCRIPTION
        By default the function creates an INFO record in the log file. To create WARNING or ERROR events, you have to specify the Err or Warn switch.
    .PARAMETER CloudProvider
        The cloud provider. Allowed values: AWS, Azure, None.  None is for a configuration that is not AWS or Azure such as an on-premises configuration.
    .PARAMETER ServerRole
        The role of the server. Allowed values: Sql, HpcHeadNode, HpcComputeNode, AwsHpcComputeNode, Qis, Interface, Olap, EtlHpcComputeNode
    .PARAMETER SqlInstanceName
        The Microsoft SQL server name.
    .PARAMETER HpcHeadNodeName
        The Microsoft HPC Head Node server name.
    .PARAMETER QisServerName
        The QRM Infrastructure Services (QIS) server name.
    .PARAMETER InstallerSourcePath
        The path where the installer files are located.
    .PARAMETER ParametersFileName
        The file name of the parameters file.
    .PARAMETER AwsSecretName
        The Aws Secret Name.
    .PARAMETER AzureKeyVaultName
        The Azure Key Vault Name.
    .PARAMETER CreateScheduledTask
        Creates a scheduled task to ensure proper server role configuration.
    .EXAMPLE
        .\QrmEnvironmentInstallationConfiguration.ps1 -ServerRole HpcComputeNode
#>
Param (
    [Parameter(Mandatory = $true)] [ValidateSet('AWS', 'Azure', 'None')] [string] $CloudProvider,
    [Parameter(Mandatory = $true)] [ValidateSet('Sql', 'HpcHeadNode', 'HpcComputeNode', 'AwsHpcComputeNode', 'Qis', 'Interface', 'Olap', 'EtlHpcComputeNode', 'AzureHpcConfigManager')] [string[]] $ServerRole,
    [Parameter(Mandatory = $false)] [string] $SqlInstanceName,
    [Parameter(Mandatory = $false)] [string] $HpcHeadNodeName,
    [Parameter(Mandatory = $false)] [string] $QisServerName,
    [Parameter(Mandatory = $false)] [string] $InstallerSourcePath = 'C:\QRMInstaller',
    [Parameter(Mandatory = $false)] [string] $ParametersFileName = 'QrmEnvironmentConfig.psd1',
    [Parameter(Mandatory = $false)] [string] $TerraformVariablesFile,
    [Parameter(Mandatory = $false)] [string] $AwsSecretName,
    [Parameter(Mandatory = $false)] [string] $AzureKeyVaultName,
    [Parameter(Mandatory = $false)] [bool] $CreateScheduledTask = $true
)

function Get-AzureSecret {
    param (
        [string] $AzureKeyVaultName
    )
    $Response = Invoke-RestMethod -Uri 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fvault.azure.net' -Method GET -Headers @{Metadata = "true" }
    $KeyVaultToken = $Response.access_token

    $Secret = Invoke-RestMethod -Uri "https://$($AzureKeyVaultName).vault.azure.net/secrets/DomainDnsName?api-version=2016-10-01" -Method GET -Headers @{Authorization = "Bearer $KeyVaultToken" }
    $DomainDnsName = $Secret.Value

    $Secret = Invoke-RestMethod -Uri "https://$($AzureKeyVaultName).vault.azure.net/secrets/DomainNetBIOSName?api-version=2016-10-01" -Method GET -Headers @{Authorization = "Bearer $KeyVaultToken" }
    $DomainNetBIOSName = $Secret.Value
    
    $Secret = Invoke-RestMethod -Uri "https://$($AzureKeyVaultName).vault.azure.net/secrets/DomainAdminUser?api-version=2016-10-01" -Method GET -Headers @{Authorization = "Bearer $KeyVaultToken" }
    $DomainAdminUser = $Secret.Value
    
    $Secret = Invoke-RestMethod -Uri "https://$($AzureKeyVaultName).vault.azure.net/secrets/MicrosoftADPassword?api-version=2016-10-01" -Method GET -Headers @{Authorization = "Bearer $KeyVaultToken" }
    $MicrosoftADPassword = $Secret.Value
    
    $Secret = Invoke-RestMethod -Uri "https://$($AzureKeyVaultName).vault.azure.net/secrets/QisServiceUser?api-version=2016-10-01" -Method GET -Headers @{Authorization = "Bearer $KeyVaultToken" }
    $QisServiceUser = $Secret.Value
    
    $Secret = Invoke-RestMethod -Uri "https://$($AzureKeyVaultName).vault.azure.net/secrets/QisServicePassword?api-version=2016-10-01" -Method GET -Headers @{Authorization = "Bearer $KeyVaultToken" }
    $QisServicePassword = $Secret.Value
    
    $Secret = Invoke-RestMethod -Uri "https://$($AzureKeyVaultName).vault.azure.net/secrets/DatabaseAdminUser?api-version=2016-10-01" -Method GET -Headers @{Authorization = "Bearer $KeyVaultToken" }
    $DatabaseAdminUser = $Secret.Value

    $Secret = Invoke-RestMethod -Uri "https://$($AzureKeyVaultName).vault.azure.net/secrets/DatabaseAdminPassword?api-version=2016-10-01" -Method GET -Headers @{Authorization = "Bearer $KeyVaultToken" }
    $DatabaseAdminPassword = $Secret.Value
    
    $Secret = Invoke-RestMethod -Uri "https://$($AzureKeyVaultName).vault.azure.net/secrets/QrmSqlUser?api-version=2016-10-01" -Method GET -Headers @{Authorization = "Bearer $KeyVaultToken" }
    $QrmSqlUser = $Secret.Value

    $Secret = Invoke-RestMethod -Uri "https://$($AzureKeyVaultName).vault.azure.net/secrets/QrmSqlPassword?api-version=2016-10-01" -Method GET -Headers @{Authorization = "Bearer $KeyVaultToken" }
    $QrmSqlPassword = $Secret.Value

    $Secret = Invoke-RestMethod -Uri "https://$($AzureKeyVaultName).vault.azure.net/secrets/QrmUsersGroup?api-version=2016-10-01" -Method GET -Headers @{Authorization = "Bearer $KeyVaultToken" }
    $QrmUsersGroup = $Secret.Value

    $Secret = Invoke-RestMethod -Uri "https://$($AzureKeyVaultName).vault.azure.net/secrets/QrmAdminsGroup?api-version=2016-10-01" -Method GET -Headers @{Authorization = "Bearer $KeyVaultToken" }
    $QrmAdminsGroup = $Secret.Value
    
    $Secrets = @{
        DomainNetBIOSName     = $DomainNetBIOSName
        DomainDnsName         = $DomainDnsName
        DomainAdminUser       = $DomainAdminUser
        MicrosoftADPassword   = $MicrosoftADPassword
        DatabaseAdminUser     = $DatabaseAdminUser
        DatabaseAdminPassword = $DatabaseAdminPassword
        QisServiceUser        = $QisServiceUser
        QisServicePassword    = $QisServicePassword
        QrmSqlUser            = $QrmSqlUser
        QrmSqlPassword        = $QrmSqlPassword
        QrmUsersGroup         = $QrmUsersGroup
        QrmAdminsGroup        = $QrmAdminsGroup
    }
    return $Secrets    
}
function GetAzureServerDrive {
    param(
        [string] $DiskLun
    )

    $AllPhysicalDisks = Get-PhysicalDisk -CanPool $true | Select-Object -Property DeviceId, CanPool, FriendlyName, PhysicalLocation, Size

    if (($AllPhysicalDisks | Measure-Object).Count -eq 1) {
        WriteLog -LogString 'Single disk found'
    }
    else {
        WriteLog -LogString 'Multiple disks found'
    }
    foreach ($PhysicalDisk in $AllPhysicalDisks) {
        $RawLun = $PhysicalDisk.PhysicalLocation.Split(':')
        $LUN = $RawLun[$RawLun.Count - 1].Trim(' ')    
        if ($LUN.Split(' ')[1] -eq $DiskLun) {
            $RawDisk = Get-Disk -Number $PhysicalDisk.DeviceId
            try {
                $DriveLetter = (Get-Partition -DiskNumber $PhysicalDisk.DeviceId -ErrorAction Stop | Select-Object -Property Driveletter).DriveLetter -Match '^[a-zA-Z]'
                WriteLog -LogString "Drive letter for Disk $($PhysicalDisk.DeviceId)  is `"$DriveLetter`"."
            }
            catch {
                WriteLog -LogString "Drive letter for Disk $($PhysicalDisk.DeviceId)  NOT FOUND . $($_.Exception)." 
            }
            $Disk = New-Object PSObject -Property @{
                Path        = $RawDisk.Path
                DiskNumber  = $RawDisk.DiskNumber
                Partition   = $RawDisk.PartitionNumber
                DriveLetter = "$DriveLetter"
                Size        = $RawDisk.Size
                Device      = $Device
                Location    = $PhysicalDisk.PhysicalLocation
            }
        }
    }
    WriteLog -LogString $Disk | Format-Table -AutoSize -Property Path, DiskNumber, Partition, DriveLetter, Device, Size   
    return $Disk 
}
function GetAwsServerDrive {
    param(
        [string] $Path
    )
    #xvdf = SQL data drive
    #xvdg = SQL log drive
    #xvdh = SQL tempDB drive
    #xvdi = SQL OLAP data drive
    $SerialNumber = (Get-Disk -Path $Path).SerialNumber
    if ($SerialNumber -clike 'vol*') {
        $EbsVolumeId = $SerialNumber.Substring(0, 20).Replace("vol", "vol-")
    }
    else {
        $EbsVolumeId = $SerialNumber.Substring(0, 20).Replace("AWS", "AWS-")
    }

    if ($EbsVolumeId -clike 'vol*') {
        try {
            $Device = ((Get-EC2Volume -VolumeId $EbsVolumeId -ErrorAction Stop).Attachment).Device
            WriteLog -LogString "Device Name for $EbsVolumeId is `"$Device`"."
        }
        catch {
            WriteLog -LogString "Device name NOT FOUND. $($_.Exception)." 
        }   
    }
    else {
        $Device = "Ephemeral"
    }
    $DiskNumber = (Get-Disk -Path $Path).Number
    if ($DiskNumber -eq 0) {
        $DriveLetter = "C"
        $PartitionNumber = (Get-Partition -DriveLetter C).PartitionNumber
    }
    else {
        try {
            $DriveLetter = (Get-Partition -DiskNumber $DiskNumber -ErrorAction Stop | Select-Object -Property Driveletter).DriveLetter -Match '^[a-zA-Z]'
            WriteLog -LogString "Drive letter for Disk $DiskNumber  is `"$DriveLetter`"."
        }
        catch {
            WriteLog -LogString "Drive letter for Disk $DiskNumber  NOT FOUND . $($_.Exception)." 
        }
        if (!$DriveLetter) {
            try {
                $DriveLetter = ((Get-Partition -DiskId $Path -ErrorAction Stop).AccessPaths).Split(",")[0]
                WriteLog -LogString "Access Path `"$DriveLetter`" found for Disk $DiskNumber."
            }
            catch {
                WriteLog -LogString "Access Path for Disk $DiskNumber NOT FOUND . $($_.Exception)." 
            }
        } 
        $PartitionNumber = (Get-Partition -DiskId $Path).PartitionNumber   
    }
    $Size = (Get-Disk -Path $Path).Size
    $Disk = New-Object PSObject -Property @{
        Path        = $Path
        DiskNumber  = $DiskNumber
        Partition   = $PartitionNumber
        DriveLetter = "$DriveLetter"
        Size        = $Size
        EbsVolumeId = $EbsVolumeId
        Device      = $Device
    }
    WriteLog -LogString $Disk | Format-Table -AutoSize -Property Path, DiskNumber, Partition, DriveLetter, Device, EbsVolumeId, Size   
    return $Disk 
}
function SetServerDrive {
    param(
        [PSObject] $Disk,
        [string] $FolderPath
    )
    #xvdf = SQL data drive
    #xvdg = SQL log drive
    #xvdh = SQL tempDB drive
    #xvdi = SQL OLAP data drive 
    #Get-Item -Path $FolderPath -ErrorAction SilentlyContinue
    #$Partition = Get-Partition -DriveLetter $DriveLetter
    $DriveLetter = $FolderPath.Split(':')[0]
    WriteLog -LogString "Drive letter will be `"$DriveLetter`"."
    if (!(Test-Path -Path $FolderPath -ErrorAction SilentlyContinue)) {
        Initialize-Disk -Number $Disk.DiskNumber -ErrorAction Continue
        New-Partition -DiskNumber $Disk.DiskNumber -UseMaximumSize -DriveLetter $DriveLetter -ErrorAction Continue
        Format-Volume -DriveLetter $DriveLetter -ErrorAction Continue
        try {
            $NewFolder = New-Item -Path $FolderPath -ItemType Directory -ErrorAction Stop
            WriteLog -LogString "Successfully created new folder `"$NewFolder`"."   
        }
        catch {
            WriteLog -LogString "Cannot create new folder. $($_.Exception)."
        }          
    }
}
function SetupOlapDrives {
    param (
        [string] $OlapServiceName = 'MSSQLServerOLAPService',
        [string] $FolderPath = 'O:\OlapData'
    )

    $DataDir = Join-Path -Path $FolderPath -ChildPath 'Data'
    $LogDir = Join-Path -Path $FolderPath -ChildPath 'Log'
    $BackUpDir = Join-Path -Path $FolderPath -ChildPath 'Backup'
    if ((Test-Path -Path $FolderPath -ErrorAction SilentlyContinue)) {
    
        if (!(Test-Path -Path $DataDir -ErrorAction SilentlyContinue)) {
            New-Item -Path $DataDir -ItemType Directory -Force  
        }
        if (!(Test-Path -Path $LogDir -ErrorAction SilentlyContinue)) {
            New-Item -Path $LogDir -ItemType Directory -Force  
        }    
        if (!(Test-Path -Path $BackUpDir -ErrorAction SilentlyContinue)) {
            New-Item -Path $BackUpDir -ItemType Directory -Force  
        }

        try {
            $OlapService = Get-WmiObject -Class Win32_Service -Filter "Name like '$OlapServiceName'" -ErrorAction Stop
            WriteLog -LogString "OLAP service command line. $($OlapService.PathName)"
            $OlapConfigPath = $OlapService.PathName.Split('"')[3]
            WriteLog -LogString "OLAP service config folder. $($OlapConfigPath)"
            $OlapConfigFile = Join-Path -Path $OlapConfigPath -ChildPath 'msmdsrv.ini' -ErrorAction Stop
            Test-Path -Path $OlapConfigFile -ErrorAction Stop
            WriteLog -LogString "OLAP service configuration file. $($OlapConfigFile)"
            [XML]$XMLcontent = Get-Content -Path $OlapConfigFile -ErrorAction Stop
            $SaveFile = $false
            if ($XMLcontent.ConfigurationSettings.DataDir -ne $DataDir) {
                $XMLcontent.ConfigurationSettings.DataDir = $DataDir.ToString()
                $SaveFile = $true
            }
            else {
                WriteLog -LogString "The OLAP DataDir already configured. $($XMLcontent.ConfigurationSettings.DataDir)" 
            }
            if ($XMLcontent.ConfigurationSettings.LogDir -ne $LogDir) {
                $XMLcontent.ConfigurationSettings.LogDir = $LogDir.ToString()
                $SaveFile = $true
            }
            else {
                WriteLog -LogString "The OLAP LogDir already configured. $($XMLcontent.ConfigurationSettings.LogDir)" 
            }
            if ($XMLcontent.ConfigurationSettings.BackUpDir -ne $BackUpDir) {
                $XMLcontent.ConfigurationSettings.BackUpDir = $BackUpDir.ToString()
                $SaveFile = $true
            }
            else {
                WriteLog -LogString "The OLAP BackUpDir already configured. $($XMLcontent.ConfigurationSettings.BackUpDir)" 
            }
            if ($SaveFile -eq $true) {
                $XMLcontent.Save($OlapConfigFile)
                Stop-Service -Name $OlapServiceName -Force -ErrorAction Stop
                Start-Service -Name $OlapServiceName -ErrorAction Stop 
            }     
        }
        catch {
            WriteLog -LogString "Failed to configure OLAP server drives. $($_.Exception)" 
        }
    }
    else {
        WriteLog -LogString "Cannot find folder $FolderPath." 
    }
}
function CreateScheduledTask {
    param (
        [string] $TaskName,
        [string] $TaskArguments,
        [pscredential] $Credential,
        [switch] $AtSystemStartup
    )

    try {
        $CurrentTask = Get-ScheduledTask -TaskName $TaskName -ErrorAction Stop
        WriteLog -LogString "Scheduled Task $TaskName already exists."
    }
    catch {
        WriteLog -LogString "Scheduled Task $TaskName does not exist. $($_.Exception)"
    }    
    if (!$CurrentTask) {
        WriteLog -LogString "Creating Scheduled Task $TaskName."

        $Action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $TaskArguments
        if ($AtSystemStartup) {
            $Trigger = New-ScheduledTaskTrigger -AtStartup
        }
        else {
            $Trigger = New-ScheduledTaskTrigger -Once -At ((Get-date).AddMinutes(5)) -RepetitionDuration (New-TimeSpan -Hours 1) -RepetitionInterval (New-TimeSpan -Minutes 5)
        }
        
        $TaskSettings = New-ScheduledTaskSettingsSet -RunOnlyIfNetworkAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 1) -MultipleInstances IgnoreNew

        if ($Credential) {
            $UserName = $Credential.UserName
            $Password = $Credential.GetNetworkCredential().password
            $Principal = New-ScheduledTaskPrincipal $UserName -RunLevel Highest
            $NewTask = New-ScheduledTask -Action $Action -Principal $Principal -Trigger $Trigger -Settings $TaskSettings
            Register-ScheduledTask $TaskName -InputObject $NewTask
            Set-ScheduledTask -TaskName $TaskName -User $UserName -Password $Password
        }
        else {
            $Principal = New-ScheduledTaskPrincipal 'NT AUTHORITY\SYSTEM' -RunLevel Highest -LogonType ServiceAccount
            $NewTask = New-ScheduledTask -Action $Action -Principal $Principal  -Trigger $Trigger -Settings $TaskSettings
            Register-ScheduledTask $TaskName -InputObject $NewTask
        } 
    }
}
function WriteLog {
    Param ([Parameter(Mandatory = $true)] [string] $LogString)
    $DateTimeString = Get-Date -Format s
    Add-content $Logfile -value "$($DateTimeString): $($LogString)"
    Write-Information -MessageData "$($DateTimeString): $($LogString)" -InformationAction Continue
}
function FindSetupFile {
    Param ([string] $Path, [string] $Extension, [string] $FileNameStartsWith)

    if (!(Test-Path -Path $Path -ErrorAction SilentlyContinue)) {
        WriteLog -LogString "Folder $Path does not exist."
    }
    else {
        try {
            $Installer = Get-ChildItem -Path $Path -Include "*.$Extension" -Recurse -File -ErrorAction Stop | Where-Object { $_.Name.StartsWith("$FileNameStartsWith") }
            if (!$Installer.FullName) {
                WriteLog -LogString "Cannot find the Setup file."
            }
            else {
                WriteLog -LogString "Found the Setup file $($Installer.FullName)."
                return $Installer.FullName
            }    
        }
        catch {
            WriteLog -LogString "Failed to find the Setup File $($Installer.FullName). $($_.Exception)"
        }
    }
}
function SetupADaccount {
    param ([string] $Identity, [string] $Password, [switch] $Group, [PSCredential] $Credential)    
    if ($Group) {
        try {
            $AdIdentity = Get-ADGroup -Identity $Identity -Credential $Credential -ErrorAction Stop
        }
        catch {
            WriteLog -LogString "Group $Identity does not exist."
        }
        if (!($AdIdentity)) {
            try {
                New-ADGroup -Name $Identity -GroupScope Global -Credential $Credential -ErrorAction Stop
                WriteLog -LogString "Successfully created group $Identity."
            }
            catch {
                WriteLog -LogString "Failed to create Group $Identity. $($_.Exception)"
                return $false
            }            
        }
        else {
            WriteLog -LogString "Group $Identity already exists."
        }
    }
    else {
        try {
            $AdIdentity = Get-ADUser -Identity $Identity -Credential $Credential -ErrorAction Stop
        }
        catch {
            WriteLog -LogString "User $Identity does not exist." 
        }
        if (!($AdIdentity)) {
            try {
                $AccountPassword = ConvertTo-SecureString $Password -AsPlainText -Force -ErrorAction Stop
                New-ADUser -Name $Identity -AccountPassword $AccountPassword -ChangePasswordAtLogon $false -Enabled $true -Credential $Credential -ErrorAction Stop
                WriteLog -LogString "Successfully created User $Identity." 
            }
            catch {
                WriteLog -LogString "Failed to create User $Identity. $($_.Exception)"
                return $false 
            }
        }
        else {
            WriteLog -LogString "User $Identity already exists."   
        }
    }
    return $true
}
function ExtractQrmInstallationFiles {
    param ([string]$ArchiveFile, [string]$DestinationFolder)    
    if (!(Test-Path -Path $DestinationFolder)) {
        WriteLog -LogString "Extracting $ArchiveFile"

        $InstallResult = Start-Process -FilePath $ArchiveFile -ArgumentList "/s /d$($DestinationFolder.TrimEnd('\'))" -ErrorVariable Err
        if ($Err) {
            WriteLog -LogString "Extraction of $ArchiveFile failed. ExitCode = $($InstallResult.ExitCode): $($Err)"
        }
        else {
            WriteLog -LogString "Extraction of $ArchiveFile successfull. ExitCode = $($InstallResult.ExitCode)"               
        }
        $Counter = 0
        while ($Counter -lt 5) {
            Start-Sleep -Seconds 60
            $QrmCentralizedInstaller = Get-Process | Where-Object -Property Path -eq "C:\QRMInstaller\QRMInstaller\Setup.exe"
            if ($QrmCentralizedInstaller.Id) {
                WriteLog -LogString "Found process QRM Centralized Installer Browser. $($QrmCentralizedInstaller.Id)"
                Stop-Process -Id $QrmCentralizedInstaller.Id -Force
                WriteLog -LogString "Killed process QRM Centralized Installer Browser. $($QrmCentralizedInstaller.Id)"
                return $true
            }
            else {
                $Counter++
            }
            if ($Counter -eq 5) {
                WriteLog -LogString "Could not find process QRM Centralized Installer Browser after 5 attempts"
            }
        }
    }
    else {
        WriteLog -LogString "Folder $DestinationFolder already exists." 
    }
    return $true    
}
function ExtractZipArchive {
    param ([string]$ArchiveFile, [string]$DestinationFolder)  
    if (!(Test-Path -Path $DestinationFolder)) {
        WriteLog -LogString "Extracting $ArchiveFile"
        try {
            Expand-Archive -Path $ArchiveFile -DestinationPath $DestinationFolder -Force -ErrorAction Stop
            WriteLog -LogString "Successfully extracted the contents of $ArchiveFile"   
        }
        catch {
            WriteLog -LogString "Failed to extract the contents of $ArchiveFile. (err=$($_.Exception))"
            return $false 
        }        
    }
    else {
        WriteLog -LogString "Folder $DestinationFolder already exists." 
    }
    return $true 
}
function InstallDotNet {
    param ([string]$DotNetInstaller)  
    
    $NetInstallResult = Start-Process -FilePath $DotNetInstaller -ArgumentList '/q /norestart /log "C:\QRMInstaller\DotNET48-Instal.log"' -Wait -PassThru
    WriteLog -LogString ".NET 48 Installation Exit Code = $($NetInstallResult.ExitCode)." 
    if ($NetInstallResult.ExitCode -eq 3010) {
        Restart-Computer -Confirm:$false
    }       
    #C:\Qrminstaller\Qrminstaller\Redistributables\ndp48-x86-x64-allos-enu.exe
}
function InstallHpcHeadNode {
    param ([string] $HpcPackInstallationSource, [string] $CertificateThumbprint)
    $ServiceStatus = (Get-Service -Name HpcScheduler -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Status)
    if ($ServiceStatus) {
        WriteLog -LogString "HPC Pack Head Node role already installed. Scheduler service is $($ServiceStatus)."
        return 0
    }
    $SqlSetupFile = Join-Path -Path $HpcPackInstallationSource -ChildPath '\amd64\SQLEXPR_x64_ENU.exe'
    $SqlArgumentList = '/q /action=install /features=sqlengine /instancename=COMPUTECLUSTER /sqlsvcaccount="NT AUTHORITY\SYSTEM" /browsersvcstartuptype="automatic" /sqlsysadminaccounts="builtin\administrators" /TCPENABLED=1 /IACCEPTSQLSERVERLICENSETERMS'
    $SqlInstallResult = Start-Process -FilePath $SqlSetupFile -ArgumentList $SqlArgumentList -Wait -PassThru
    WriteLog -LogString "SQL Express Installation Exit Code = $($SqlInstallResult.ExitCode)."

    $SetupFile = Join-Path -Path $HpcPackInstallationSource -ChildPath 'setup.exe'
    $ArgumentList = "-unattend -Quiet -headNode -SkipComponent:rras,dhcp,wds -SSLThumbprint:$CertificateThumbprint"
    $InstallResult = Start-Process -FilePath $SetupFile -ArgumentList $ArgumentList -Wait -PassThru
    if ($InstallResult.ExitCode -eq 0) {
        WriteLog -LogString "Succeeded Installing the HPC Pack Head Node"
    }
    elseif ($InstallResult.ExitCode -eq 3010) {
        WriteLog -LogString "Succeeded Installing the HPC Pack Head Node. A reboot is required."
    }
    elseif ($InstallResult.ExitCode -eq 13818) {
        WriteLog -LogString "Failed to Install the HPC Pack Head Node (errCode=$($InstallResult.ExitCode)): the certificate does not meet the requirements."
    }
    else {
        WriteLog -LogString "Failed to Install the HPC Pack Head Node (errCode=$($InstallResult.ExitCode))"
    }
    return $InstallResult.ExitCode
}
function ConfigureHpcHeadNode {
    param (
        [PSObject] $InputParameters
    )
    $Status = $true
    try {
        $env:PSModulePath = [System.Environment]::GetEnvironmentVariable("PSModulePath", "Machine") + ";" + "$HOME\Documents\WindowsPowerShell\Modules"
        #Import-module -name 'C:\Program Files\Microsoft HPC Pack 2019\PowerShell\Microsoft.Hpc' -DisableNameChecking -ErrorAction Stop
        Import-module -Name Microsoft.Hpc -DisableNameChecking -Force -ErrorAction Stop
        WriteLog -LogString " Successfully imported the HPC PowerShell module."
    }
    catch {
        WriteLog -LogString "Failed to import the HPC PowerShell module. $($_.Exception)"
    }
    Set-Content Env:CCP_CONNECTIONSTRING $InputParameters.HpcHeadNodeName
    #Configure Network
    try {
        $CurrentTopology = Get-HpcNetworkTopology -ErrorAction Stop
        WriteLog -LogString "Current HPC cluster network topology is $CurrentTopology."
    }
    catch {
        WriteLog -LogString "Cannot get the HPC cluster network topology. $($_.Exception)"
    }

    if ($CurrentTopology -ne 'Enterprise') {
        $RetryCount = 0
        while ($true) {
            try {
                $IfIndex = (Get-NetIPInterface -ErrorAction Stop | Where-Object { $_.Dhcp -eq 'enabled' } | Select-Object -First 1).ifIndex
                $Nic = (Get-NetAdapter -InterfaceIndex $IfIndex -ErrorAction Stop).InterfaceDescription
                Set-HpcNetwork -Topology 'Enterprise' -Enterprise $Nic -EnterpriseFirewall $False -ErrorAction Stop
                WriteLog -LogString "Successfully set the HPC Enterprise network topology for NIC: $Nic."
                break
            }
            catch {
                if ($RetryCount++ -ge 4) {
                    WriteLog -LogString "Failed to set the HPC network topology. $($_.Exception)"
                    $Status = $false
                    break
                }
                else {
                    WriteLog -LogString "Setting the HPC network topology. Waiting for 15 seconds ..."
                    Start-Sleep -Seconds 15
                }
            }
        }        
    }
    else {
        WriteLog -LogString "The HPC Enterprise network topology is already set to $CurrentTopology." 
    }

    #Provide Installation Credentials
    try {
        $CurrentInstallCredential = (Get-HpcClusterProperty -InstallCredential -ErrorAction Stop).Value
        WriteLog -LogString "Current HPC InstallCredential = $CurrentInstallCredential"
    }
    catch {
        WriteLog -LogString "Cannot get the current HPC InstallCredential. $($_.Exception)" 
    }
    if ($CurrentInstallCredential -ne "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser)") {
        $RetryCount = 0
        WriteLog -LogString "Setting HPC InstallCredential."
        while ($true) {
            $InstallCredential = New-Object System.Management.Automation.PSCredential ("$($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser)", (ConvertTo-SecureString $InputParameters.QisServicePassword -AsPlainText -Force -ErrorAction Continue))
            try {
                Set-HpcClusterProperty -InstallCredential $InstallCredential -ErrorAction Stop
                WriteLog -LogString "Successfully set HPC InstallCredential."
                break
            }
            catch {
                if ($RetryCount++ -ge 4) {
                    WriteLog -LogString "Failed to set HPC InstallCredential: $($_.Exception)"
                    $Status = $false
                    break
                }
                else {
                    WriteLog -LogString "Setting HPC InstallCredential. Waiting for 15 seconds ..."
                    Start-Sleep -Seconds 15
                }
            }
        }
    }
    else {
        WriteLog -LogString "HPC InstallCredential already set. $CurrentInstallCredential"
    }

    #Configure Naming of compute nodes
    try {
        $CurrentNodeNamingSeries = (Get-HpcClusterProperty -NodeNamingSeries -ErrorAction Stop).Value
        WriteLog -LogString "Current HPC NodeNamingSeries = $CurrentNodeNamingSeries"
    }
    catch {
        WriteLog -LogString "Failed to get NodeNamingSeries: $($_.Exception)"
    }
    if ($CurrentNodeNamingSeries -ne 'CN-%1000%') {
        $RetryCount = 0
        WriteLog -LogString  "Setting Node naming series to CN-%1000%"
        while ($true) {
            try {
                Set-HpcClusterProperty -NodeNamingSeries 'CN-%1000%' -ErrorAction Stop
                WriteLog -LogString "Successfully set NodeNamingSeries to CN-%1000%"
                break
            }
            catch {
                if ($Retry++ -ge 4) {
                    WriteLog -LogString "Failed to set NodeNamingSeries: $($_.Exception)"
                    $Status = $false
                    break
                }
                else {
                    WriteLog -LogString  "Setting NodeNamingSeries. Waiting for 15 seconds ..."
                    Start-Sleep -Seconds 15
                }
            }
        }
    }

    #Create Node groups
    #Compute
    try {
        $CurrentNodeGroup = Get-HpcGroup -Name $InputParameters.HpcComputeNodeGroup -ErrorAction Stop
        WriteLog -LogString  "Found HPC Group $CurrentNodeGroup."
    }
    catch {
        WriteLog -LogString  "Cannot get HPC Group $($InputParameters.HpcComputeNodeGroup). $($_.Exception)"
    }
    if (!$CurrentNodeGroup) {
        $RetryCount = 0
        WriteLog -LogString  "Creating HPC Group $($InputParameters.HpcComputeNodeGroup)"
        while ($true) {
            try {
                New-HpcGroup -Name $InputParameters.HpcComputeNodeGroup -Description $InputParameters.HpcComputeNodeGroup -ErrorAction Stop
                WriteLog -LogString  "Successfully created $($InputParameters.HpcComputeNodeGroup)."
                break
            }
            catch {
                if ($Retry++ -ge 4) {
                    WriteLog -LogString  "Failed to Create $($InputParameters.HpcComputeNodeGroup). $($_.Exception)"
                    $Status = $false
                    break
                }
                else {
                    WriteLog -LogString  "Creating HPC Group $($InputParameters.HpcComputeNodeGroup). Waiting for 15 seconds ..."
                    Start-Sleep -Seconds 15
                }
            }
        }
    }
    #ETL
    try {
        $CurrentNodeGroup = Get-HpcGroup -Name $InputParameters.HpcEtlNodeGroup -ErrorAction Stop
        WriteLog -LogString  "Found HPC Group $CurrentNodeGroup."
    }
    catch {
        WriteLog -LogString  "Cannot get HPC Group $($InputParameters.HpcEtlNodeGroup). $($_.Exception)"
    }
    if (!$CurrentNodeGroup) {
        $RetryCount = 0
        WriteLog -LogString  "Creating HPC Group $($InputParameters.HpcEtlNodeGroup)"
        while ($true) {
            try {
                New-HpcGroup -Name $InputParameters.HpcEtlNodeGroup -Description $InputParameters.HpcEtlNodeGroup -ErrorAction Stop
                WriteLog -LogString  "Successfully created $($InputParameters.HpcEtlNodeGroup)."
                break
            }
            catch {
                if ($Retry++ -ge 4) {
                    WriteLog -LogString  "Failed to create $($InputParameters.HpcEtlNodeGroup). $($_.Exception)"
                    $Status = $false
                    break
                }
                else {
                    WriteLog -LogString  "Creating HPC Group $($InputParameters.HpcEtlNodeGroup). Waiting for 15 seconds ..."
                    Start-Sleep -Seconds 15
                }
            }
        }
    }
    #create Job templates
    #default
    try {
        $HpcJobTemplate = Get-HpcJobTemplate -Name $InputParameters.DefaultJobTemplateName -ErrorAction Stop
        WriteLog -LogString "Found the HPC Job Template $HpcJobTemplate."
    }
    catch {
        WriteLog -LogString "Cannot get the HPC Job Template $($InputParameters.DefaultJobTemplateName). $($_.Exception)"
    }
    if (!$HpcJobTemplate) {
        $RetryCount = 0
        WriteLog -LogString  "Creating the HPC Job Template $($InputParameters.DefaultJobTemplateName)"
        while ($true) {
            try {
                $HpcTemplateXml = NewHPCJobTemplate -ComputeNodeGroup $InputParameters.HpcComputeNodeGroup -JobTemplate $InputParameters.DefaultJobTemplateName 
                Import-HpcJobtemplate -name $InputParameters.DefaultJobTemplateName -Path $HpcTemplateXml -ErrorAction Stop
                WriteLog -LogString  "Successfully created $($InputParameters.DefaultJobTemplateName)."
                break
            }
            catch {
                if ($retry++ -ge 4) {
                    WriteLog -LogString  "Failed to create the HPC Job Template $($InputParameters.DefaultJobTemplateName). $($_.Exception)"
                    $Status = $false
                    break
                }
                else {
                    WriteLog -LogString  "Creating the HPC Job Template $($InputParameters.DefaultJobTemplateName). Waiting for 15 seconds ..."
                    Start-Sleep -Seconds 15
                }
            }
        }
    }
    #ETL
    try {
        $HpcJobTemplate = Get-HpcJobTemplate -Name $InputParameters.EtlJobTemplateName -ErrorAction Stop
        WriteLog -LogString "Found HPC Job Template $HpcJobTemplate."
    }
    catch {
        WriteLog -LogString "Cannot get HPC Job Template $($InputParameters.EtlJobTemplateName). $($_.Exception)"
    }
    if (!$HpcJobTemplate) {
        $RetryCount = 0
        WriteLog -LogString  "Creating HPC Job Template $($InputParameters.EtlJobTemplateName)"
        while ($true) {
            try {
                $HpcTemplateXml = NewHPCJobTemplate -ComputeNodeGroup $InputParameters.HpcEtlNodeGroup -JobTemplate $InputParameters.EtlJobTemplateName
                Import-HpcJobtemplate -name $InputParameters.EtlJobTemplateName -Path $HpcTemplateXml -ErrorAction Stop
                WriteLog -LogString  "Successfully created $($InputParameters.EtlJobTemplateName)."
                break
            }
            catch {
                if ($retry++ -ge 4) {
                    WriteLog -LogString  "Failed to create the HPC Job Template $($InputParameters.EtlJobTemplateName). $($_.Exception)"
                    $Status = $false
                    break
                }
                else {
                    WriteLog -LogString  "Creating the HPC Job Template $($InputParameters.EtlJobTemplateName). Waiting for 15 seconds ..."
                    Start-Sleep -Seconds 15
                }
            }
        }
    }
    #Add Users
    #Service Account
    try {
        $CurrentMember = Get-HpcMember -Name "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser)" -Role JobAdministrator -ErrorAction Stop
        WriteLog -LogString  "Found the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser)"
    }
    catch {
        WriteLog -LogString  "Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser) does not exist. $($_.Exception)"
    }
    if (!$CurrentMember) {
        $RetryCount = 0
        WriteLog -LogString  "Creating the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser)"
        while ($true) {
            try {
                Add-HpcMember -Name "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser)" -Role JobAdministrator -ErrorAction Stop
                WriteLog -LogString  "Successfully created the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser)."
                break
            }
            catch {
                if ($retry++ -ge 4) {
                    WriteLog -LogString  "Failed to create the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser). $($_.Exception)"
                    $Status = $false
                    break
                }
                else {
                    WriteLog -LogString  "Creating the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser). Waiting for 15 seconds ..."
                    Start-Sleep -Seconds 15
                }
            }
        }
    }
    #Users
    try {
        $CurrentMember = Get-HpcMember -Name "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup)" -Role JobAdministrator -ErrorAction Stop
        WriteLog -LogString  "Found the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup)"
    }
    catch {
        WriteLog -LogString  "Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup) does not exist. $($_.Exception)"
    }
    if (!$CurrentMember) {
        $RetryCount = 0
        WriteLog -LogString  "Creating the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup)"
        while ($true) {
            try {
                Add-HpcMember -Name "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup)" -Role JobAdministrator -ErrorAction Stop
                WriteLog -LogString  "Successfully created the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup)."
                break
            }
            catch {
                if ($retry++ -ge 4) {
                    WriteLog -LogString  "Failed to create the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup). $($_.Exception)"
                    $Status = $false
                    break
                }
                else {
                    WriteLog -LogString  "Creating the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup). Waiting for 15 seconds ..."
                    Start-Sleep -Seconds 15
                }
            }
        }
    }
    #Admins
    try {
        $CurrentMember = Get-HpcMember -Name "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmAdminsGroup)" -Role Administrator -ErrorAction Stop
        WriteLog -LogString  "Found the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmAdminsGroup)"
    }
    catch {
        WriteLog -LogString  "Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmAdminsGroup) does not exist. $($_.Exception)"
    }
    if (!$CurrentMember) {
        $RetryCount = 0
        WriteLog -LogString  "Creating the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmAdminsGroup)"
        while ($true) {
            try {
                Add-HpcMember -Name "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmAdminsGroup)" -Role Administrator -ErrorAction Stop
                WriteLog -LogString  "Successfully created the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmAdminsGroup)."
                break
            }
            catch {
                if ($retry++ -ge 4) {
                    WriteLog -LogString  "Failed to create the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmAdminsGroup). $($_.Exception)"
                    $Status = $false
                    break
                }
                else {
                    WriteLog -LogString  "Creating the Job Administrator $($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmAdminsGroup). Waiting for 15 seconds ..."
                    Start-Sleep -Seconds 15
                }
            }
        }
    }
    #Exclude ETL group from Azure Autoscaling
    try {
        Set-HpcClusterProperty -ExcludeNodeGroups $InputParameters.EtlJobTemplateName -ErrorAction Stop
        WriteLog -LogString  "ETL computenode group excluded from autoscaling.SUCCESS"
    }
    catch {
        WriteLog -LogString  "Failed to exclude ETL compute node group from Autoscaling. $($_.Exception)"
        $Status = $false
    }    
    return $Status
}
function NewHPCJobTemplate {
    Param (
        [string] $ComputeNodeGroup, [string] $JobTemplate
    )

    # this is where the document will be saved 
    $Path = "$($script:TmpFolder)\HpcJobTemplate-$($JobTemplate).xml"
    $Encoding = [System.Text.Encoding]::UTF8
 
    # get an XmlTextWriter to create the XML 
    $XmlWriter = New-Object System.XMl.XmlTextWriter($Path, $Encoding)
 
    # choose a pretty formatting 
    $xmlWriter.Formatting = 'Indented'
    $xmlWriter.Indentation = 1
    $XmlWriter.IndentChar = "`t"
 
    # write the header 
    $xmlWriter.WriteStartDocument()

    $xmlWriter.WriteStartElement('JobTemplate')
    $XmlWriter.WriteAttributeString('Name', $JobTemplate)
    $XmlWriter.WriteAttributeString('Description', "$JobTemplate job template")
    $XmlWriter.WriteAttributeString('CreateTime', "" )

    $xmlWriter.WriteStartElement('TemplateItem')
    $XmlWriter.WriteAttributeString('PropertyName', "NodeGroups")
    $XmlWriter.WriteAttributeString('Default', $ComputeNodeGroup)
    $XmlWriter.WriteAttributeString('ValueRange', "")
    $XmlWriter.WriteAttributeString('RequiredValues', $ComputeNodeGroup)
    $xmlWriter.WriteEndElement()

    $xmlWriter.WriteStartElement('TemplateItem')
    $XmlWriter.WriteAttributeString('PropertyName', "NodeGroupOp")
    $XmlWriter.WriteAttributeString('Default', "Union")
    $XmlWriter.WriteAttributeString('ValueRange', "")
    $xmlWriter.WriteEndElement()

    #finalize JobTemplate
    $xmlWriter.WriteEndElement()

    # finalize the document 
    $xmlWriter.WriteEndDocument()
    $xmlWriter.Flush()
    $xmlWriter.Close()

    return $Path
}
function InstallHpcComputeNode {
    param ([string] $HpcPackInstallationSource, [string] $CertificateThumbprint, [string] $HpcHeadNodeName)
    $ServiceStatus = (Get-Service -Name HpcNodeManager -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Status)
    if ($ServiceStatus) {
        WriteLog -LogString "HPC Compute Node role is already installed. HPC Node Manager service is $($ServiceStatus)."
        return 0
    }
    $SetupFile = Join-Path -Path $HpcPackInstallationSource -ChildPath 'setup.exe'
    $ArgumentList = "-unattend -Quiet -ComputeNode:$HpcHeadNodeName -SSLThumbprint:$CertificateThumbprint"
    WriteLog -LogString "Starting the installation of HPC ComputeNode Role. $SetupFile $ArgumentList"
    $InstallResult = Start-Process -FilePath $SetupFile -ArgumentList $ArgumentList -Wait -PassThru
    if ($InstallResult.ExitCode -eq 0) {
        WriteLog -LogString "Succeeded installing the HPC Pack ComputeNode Role"
    }
    elseif ($InstallResult.ExitCode -eq 3010) {
        WriteLog -LogString "Succeeded installing the HPC Pack Head Node. A reboot is required."
    }
    elseif ($InstallResult.ExitCode -eq 13818) {
        WriteLog -LogString "Failed to install the HPC Pack Head Node (errCode=$($InstallResult.ExitCode)): the certificate does not meet the requirements."
    }
    else {
        WriteLog -LogString "Failed to install the HPC Pack Head Node (errCode=$($InstallResult.ExitCode))"
    }
    return $InstallResult.ExitCode
}
function InstallHpcClientTools {
    param ([string] $HpcPackInstallationSource)
    # Check if it is installed already
    $SetupFile = Join-Path -Path $HpcPackInstallationSource -ChildPath 'setup.exe'
    $ArgumentList = "-unattend -Quiet -Client"
    WriteLog -LogString "Starting Installation of HPC Client tools. $SetupFile $ArgumentList"
    $InstallResult = Start-Process -FilePath $SetupFile -ArgumentList $ArgumentList -Wait -PassThru
    if ($InstallResult.ExitCode -eq 0) {
        WriteLog -LogString "Succeeded installing the HPC Client"
    }
    elseif ($InstallResult.ExitCode -eq 3010) {
        WriteLog -LogString "Succeeded installing the HPC Client. A reboot is required."
    }
    elseif ($InstallResult.ExitCode -eq 13818) {
        WriteLog -LogString "Failed to install the HPC Client (errCode=$($InstallResult.ExitCode)): the certificate does not meet the requirements."
    }
    else {
        WriteLog -LogString "Failed to install the HPC Client (errCode=$($InstallResult.ExitCode)). Check the HPC installation logs for details."
    }
    return $InstallResult.ExitCode
}
function ConfigureHpcComputeNode {
    param (
        [PSObject] $InputParameters,
        [string] $EtlComputeNodeName
    )
    try {
        Import-module -name 'C:\Program Files\Microsoft HPC Pack 2019\PowerShell\Microsoft.Hpc' -DisableNameChecking -ErrorAction Stop
    }
    catch {
        WriteLog -LogString "Failed to Import HPC powershell module. $($_.Exception)"
    }
    $Result = $true
    Set-Content Env:CCP_CONNECTIONSTRING $InputParameters.HpcHeadNodeName
    try {
        $AllNodeNames = (Get-HpcNode -Scheduler $InputParameters.HpcHeadNodeName  -ErrorAction Stop | Where-Object -Property IsHeadNode -eq $false).NetBiosName
        WriteLog -LogString "Descovering compute nodes. $AllNodeNames"             
    }
    catch {
        WriteLog -LogString "Cannot descover any compute nides. $($_.Exception)"
        return $false  
    }
    foreach ($NodeName in $AllNodeNames) {
        if ($NodeName -eq $EtlComputeNodeName) {
            $NodeGroup = $InputParameters.HpcEtlNodeGroup
        }
        else {
            $NodeGroup = $InputParameters.HpcComputeNodeGroup
        }
        try {
            $Node = Get-HpcNode -Name $NodeName -Scheduler $InputParameters.HpcHeadNodeName  -ErrorAction Stop
            WriteLog -LogString "The $($NodeName) HealthState is $($Node.HealthState) and state $($Node.NodeState)."             
        }
        catch {
            WriteLog -LogString "Cannot find $($NodeName). $($_.Exception)"
            $Result = $false  
        }
        if ($Node.HealthState -eq 'Unapproved') {
            try {
                $Output = Assign-HpcNodeTemplate -Name 'Default ComputeNode Template' -Node $Node -Scheduler $InputParameters.HpcHeadNodeName  -PassThru -Confirm:$false -ErrorAction Stop
                WriteLog -LogString "Default ComputeNode Template assigned successfully. $Output"
            }
            catch {
                WriteLog -LogString "Failed to assign Default ComputeNode Template. $($_.Exception)"
                $Result = $false
            }
            Start-Sleep -Seconds 60
        }
        else {
            WriteLog -LogString "The ComputeNode is not in the Unapproved state. Current state $($Node.HealthState)"
        }

        try {
            Add-HpcGroup -Name $NodeGroup -NodeName $NodeName -Scheduler $InputParameters.HpcHeadNodeName  -ErrorAction Stop
            WriteLog -LogString "Successfully added ComputeNode to $NodeGroup." 
        }
        catch {
            WriteLog -LogString "Failed to add ComputeNode to $NodeGroup. $($_.Exception)"
            $Result = $false
        }
        try {
            Set-HpcNodeState -Name $NodeName -State Online -Scheduler $InputParameters.HpcHeadNodeName  -ErrorAction Stop
            WriteLog -LogString "Successfully set ComputeNode online."
        }
        catch {
            WriteLog -LogString "Failed to set ComputeNode online. $($_.Exception)"
            $Result = $false
        }
    }
    return $Result    
}
function ConfigureAzureHpcCluster {
    param (
        [PSObject] $InputParameters
    )

    
    
}
function Create_AWS_Ec2instance_ServerTag {
    param (
        [string] $ServerTagName = 'SERVERNAME',
        [string] $HpcGroupTagName = 'HPCGROUP',
        [string] $HpcGroupTagValue
    )
    try {
        Import-Module AWSPowerShell -ErrorAction Stop
    }
    catch {
        WriteLog -LogString "Cannot import the AWS PowerShell module. $($_.Exception)"
    }    
    try {
        $InstanceId = (Invoke-RestMethod -Method Get -Uri http://169.254.169.254/latest/meta-data/instance-id -ErrorAction Stop)
        WriteLog -LogString "This instance ID is $($InstanceId)."
    }
    catch {
        WriteLog -LogString "Failed to get instance ID. $($_.Exception)"
    }    
    if ($InstanceId) {
        try {
            $ServerNameTag = Get-EC2Tag -ErrorAction Stop | Where-Object { $_.ResourceId -eq $InstanceId -and $_.Key -eq $ServerTagName }
            WriteLog -LogString "The current value of $($ServerNameTag.Key) is $($ServerNameTag.Value) for instance $($InstanceId)."
        }
        catch {
            WriteLog -LogString "Cannot access the instance tag $ServerTagName for instance $($InstanceId). $($_.Exception)"
        }
        if ($ServerNameTag.Value -cne $env:COMPUTERNAME) {
            try {
                New-EC2Tag -Resource $InstanceId -Force -Tag @{ Key = $ServerTagName; Value = $env:COMPUTERNAME } -ErrorAction Stop
                WriteLog -LogString "Successfully setup $ServerTagName tag with value $($env:COMPUTERNAME) for instance $($InstanceId)." 
            }
            catch {
                WriteLog -LogString "Failed to setup the tag $ServerTagName with value $($env:COMPUTERNAME) for instance $($InstanceId). $($_.Exception)" 
            }
        }
        try {
            $HpcGroupTag = Get-EC2Tag -ErrorAction Stop | Where-Object { $_.ResourceId -eq $InstanceId -and $_.Key -eq $HpcGroupTagName }
            WriteLog -LogString "The current value of $($HpcGroupTag.Key) is $($HpcGroupTag.Value) for instance $($InstanceId)."
        }
        catch {
            WriteLog -LogString "Cannot access the instance tag $HpcGroupTagName for instance $($InstanceId). $($_.Exception)"
        }
        if ($HpcGroupTag.Value -cne $HpcGroupTagValue) {
            try {
                New-EC2Tag -Resource $InstanceId -Force -Tag @{ Key = $HpcGroupTagName; Value = $HpcGroupTagValue } -ErrorAction Stop
                WriteLog -LogString "Successfully setup $HpcGroupTag tag with value $($HpcGroupTagValue) for instance $($InstanceId)." 
            }
            catch {
                WriteLog -LogString "Failed to setup the tag $HpcGroupTag with value $($HpcGroupTagValue) for instance $($InstanceId). $($_.Exception)" 
            }
        }
    } 
}
function ConfigureAwsHpcComputeNode {
    param (
        [PSObject] $InputParameters,
        [string] $ServerTagName = 'SERVERNAME',
        [string] $HpcGroupTagName = 'HPCGROUP'
    )
    try {
        Import-module -name 'C:\Program Files\Microsoft HPC Pack 2019\PowerShell\Microsoft.Hpc' -DisableNameChecking -ErrorAction Stop
    }
    catch {
        WriteLog -LogString "Failed to Import the HPC PowerShell module. $($_.Exception)"
    }
    try {
        Import-Module AWSPowerShell -ErrorAction Stop
    }
    catch {
        WriteLog -LogString "Cannot import the AWS PowerShell module. $($_.Exception)"
    }

    $UnapprovedComputeNodes = @()
    try {
        $UnapprovedComputeNodes = (Get-HpcNode -HealthState Unapproved -ErrorAction Stop).NetBiosName
        WriteLog -LogString "Found Unapproved compute nodes. $UnapprovedComputeNodes"
    }
    catch {
        WriteLog -LogString  "Unapproved compute nodes not found. $($_.Exception)"
    }

    if ($UnapprovedComputeNodes) {
        foreach ($ComputeNodeName in $UnapprovedComputeNodes) {
            $HpcGroupTag = $null
            $AWSinstance = $null
            $AWSinstance = Get-EC2Instance -ErrorAction SilentlyContinue -Filter @(@{Name = "tag:$($ServerTagName)"; Values = "$($ComputeNodeName)" })
            if ($AWSinstance.count -eq 1) {
                WriteLog -LogString "Found AWS EC2 instance $($AWSinstance.Instances.InstanceID) with tag $ServerTagName and value $($ComputeNodeName)."
                try {
                    $HpcGroupTag = Get-EC2Tag -ErrorAction Stop | Where-Object { $_.ResourceId -eq $AWSinstance.Instances.InstanceID -and $_.Key -eq $HpcGroupTagName }
                    WriteLog -LogString "The current value of $($HpcGroupTag.Key) is $($HpcGroupTag.Value) for instance $($AWSinstance.Instances.InstanceID)."
                }
                catch {
                    WriteLog -LogString "Cannot access the instance tag $HpcGroupTagName for instance $($AWSinstance.Instances.InstanceID). $($_.Exception)"
                }
                if ($HpcGroupTag) {
                    try {
                        $Node = Get-HpcNode -Name $ComputeNodeName -ErrorAction Stop
                        WriteLog -LogString "The $($ComputeNodeName) HealthState is $($Node.HealthState)."             
                    }
                    catch {
                        WriteLog -LogString "Cannot find $($ComputeNodeName). $($_.Exception)"
                    }
                    try {
                        $Output = Assign-HpcNodeTemplate -Name 'Default ComputeNode Template' -Node $Node -PassThru -Confirm:$false -ErrorAction Stop
                        WriteLog -LogString "Default ComputeNode Template assigned successfully. $Output"
                    }
                    catch {
                        WriteLog -LogString "Failed to assign Default ComputeNode Template. $($_.Exception)"
                    }
                    Start-Sleep -Seconds 5
                    try {
                        Add-HpcGroup -Name $HpcGroupTag.Value -NodeName $ComputeNodeName  -ErrorAction Stop
                        WriteLog -LogString "Successfully added the ComputeNode to $($HpcGroupTag.Value)." 
                    }
                    catch {
                        WriteLog -LogString "Failed to add the ComputeNode to $($HpcGroupTag.Value). $($_.Exception)"
                    }
                    try {
                        Set-HpcNodeState -Name $ComputeNodeName -State Online -ErrorAction Stop
                        WriteLog -LogString "Successfully set the ComputeNode online."
                    }
                    catch {
                        WriteLog -LogString "Failed to set the ComputeNode to online. $($_.Exception)"
                    }
                }
                else {
                    WriteLog -LogString "Cannot find the tag $($HpcGroupTagName) for instance $($AWSinstance.Instances.InstanceID)."
                }
            }
            else {
                WriteLog -LogString "Cannot find the single EC2 instance with tag $ServerTagName and value $ComputeNodeName. Number of Instances = $($AWSinstance.count) "
            }
        }
    } 
}
function InstallQis {
    param ( 
        [PSObject] $InputParameters,
        [string] $QisInstallerPath,
        [string] $InstallFolder,
        [int] $QisInstallType = 1, # ClientOnly = 1 or Full = 3
        [string] $QisInstallerLogFile = "$QisInstallerPath\qisinstall.log"
    )

    if (!(Test-Path -Path $QisInstallerPath -ErrorAction SilentlyContinue)) {
        WriteLog -LogString "QisInstallerPath folder $QisInstallerPath does not exist. Please correct QisInstallerPath before continue."
        return $false
    }
    else {
        try {
            $QisInstaller = Get-ChildItem -Path $QisInstallerPath -Include '*.exe' -Recurse -File -ErrorAction Stop | Where-Object { $_.Name.StartsWith('QRM Infrastructure Services') }
            WriteLog -LogString "Found the QIS Installer file $($QisInstaller.FullName)."
            if (!$QisInstaller.FullName) {
                WriteLog -LogString "Cannot find the QIS Installer file $($QisInstaller.FullName)."
                return $false
            }    
        }
        catch {
            WriteLog -LogString "Failed to find the QIS Installer $($QisInstaller.FullName). $($_.Exception)"
            return $false
        }
    }
    if (!$InstallFolder) {
        $InstallFolder = 'C:'
    }
    else {
        $InstallFolder = $InstallFolder.TrimEnd('\')
    }
    $CurrentQISversion = (Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | Where-Object { $_.DisplayName -like 'QRM Infrastructure Services' } | Select-Object -Property BundleVersion).BundleVersion

    if (!$CurrentQISversion) {
        $ArgumentList = "/norestart /quiet"
    }
    else {
        WriteLog -LogString "QIS is already installed: $CurrentQISversion"
        return $true
    }

    $QisDnsName = "$($InputParameters.QisServerName).$($InputParameters.DomainDnsName)"
    $QisEnvirontmentName = $InputParameters.EnvironmentName
    $QisAdministrators = "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmAdminsGroup)"
    $QisEnvirontmentType = $InputParameters.EnvironmentType
    $QisServicesPort = $InputParameters.QisServicesPort
    $ServiceUser = "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser)"
    $ServicePassword = $InputParameters.QisServicePassword
    $QisSqlServer = $InputParameters.QrmSqlServer
    $QisCaDb = $InputParameters.QisCaDb
    $QisWcsDb = $InputParameters.QisWcsDb
    $QisDiDb = $InputParameters.QisDiDb
    $QisThumbprint = $InputParameters.QisCertificateThumbprint
    $SqlUser = $InputParameters.QrmSqlUser
    $SqlPassword = $InputParameters.QrmSqlPassword
    $CaClientUrl = "https://$QisDnsName/qrm/ca"

    $ArgumentList += " INSTALLFOLDER=`"$($InstallFolder)`" QIS_INSTALL_TYPE=`"$($QisInstallType)`" QIS_DNS_NAME=`"$($QisDnsName)`" QIS_ENVIRONMENT_NAME=`"$($QisEnvirontmentName)`" QIS_ADMINISTRATORS=`"$($QisAdministrators)`" QIS_ENVIRONMENT_TYPE=`"$($QisEnvirontmentType)`" QIS_SERVICES_PORT=`"$($QisServicesPort)`" QIS_ACCOUNT_NAME=`"$($ServiceUser)`" QIS_ACCOUNT_PASSWORD=`"$($ServicePassword)`" QIS_SQL_SERVER=`"$($QisSqlServer)`" QIS_CA_DB=`"$($QisCaDb)`" QIS_WCS_DB=`"$($QisWcsDb)`" QIS_DI_DB=`"$($QisDiDb)`""

    If ($QisServicesPort -eq 443 -and $null -eq $QisThumbprint) {
        WriteLog -LogString "QisThumbprint is not specified."
        return $false
    }
    elseif ($QisThumbprint) {
        $ArgumentList += " QIS_THUMBPRINT=`"$($QisThumbprint)`""            
    }
    if ($InputParameters.AuthenticationMode -eq 'Windows') {
        $ArgumentList += " QIS_WIN_AUTH=1"
    }
    else {
        $ArgumentList += " QIS_SQL_USERNAME=`"$($SqlUser)`" QIS_SQL_PASSWORD=`"$($SqlPassword)`""
    }
    if ($QisInstallType -eq 3) {
        $ArgumentList += " QIS_CA_CLIENT_URL=$CaClientUrl"
    }
    if ($QisInstallerLogFile) {
        $ArgumentList = "/log $($QisInstallerLogFile) " + $ArgumentList
    }          
    Write-Debug "Arguments: $ArgumentList"        
    $Process = Start-Process -FilePath $QisInstaller.FullName -ArgumentList $ArgumentList -Wait -PassThru
    WriteLog -LogString "Installer exit code: $($Process.ExitCode). Check the log for details. $QisInstallerLogFile"
    return $InstallResult.ExitCode
}
function ConfigureQis {
    param ( [PSObject] $InputParameters)

    try {
        $env:PSModulePath = [System.Environment]::GetEnvironmentVariable("PSModulePath", "Machine") + ";" + "$HOME\Documents\WindowsPowerShell\Modules"
        Import-Module -Name QRM.QIS -Force -ErrorAction Stop
        WriteLog -LogString "Successfully imported the Qrm.Qis PowerShell module."
    }
    catch {
        WriteLog -LogString "Failed to import the Qrm.Qis PowerShell module. $($_.Exception)"
        return
    }
    try {
        if (!([string]::IsNullOrEmpty($InputParameters.CaUri))) {
            WriteLog -LogString "CaUri was provided. $($InputParameters.CaUri)"
            $CaVersion = (Get-QisVersion -CaUri $InputParameters.CaUri -ErrorAction Stop).CaVersion
            WriteLog -LogString "Successfully connected to $($InputParameters.CaUri). CA version = $($CaVersion.FullVersion)"
            $CaUri = $InputParameters.CaUri
        }
        else {
            Set-QisEnvironment -CaDnsName "$($InputParameters.QisServerName).$($InputParameters.DomainDnsName)" -ErrorAction Stop
            $CaUri = (Get-QisEnvironment).CaUri
            WriteLog -LogString "Successfully set CaUri = $CaUri"
            Set-QisEnvironment -LogFile 'C:\QrmInstaller\QisPowershellModule.log' -ErrorAction Stop
        }  
    }
    catch {
        WriteLog -LogString "Failed to set CaUri. $($_.Exception)"
        return
    }
    if ($InputParameters.AuthenticationMode -eq 'Windows') {
        $AuthenticationMode = 'Windows'
    }
    else {
        $AuthenticationMode = 'SqlServer'
        $SqlCredential = New-Object System.Management.Automation.PSCredential ("$($InputParameters.QrmSqlUser)", (ConvertTo-SecureString $InputParameters.QrmSqlPassword -AsPlainText -Force -ErrorAction Continue))
    }
    if (([System.Uri]$InputParameters.WorkingFolder).IsUnc -and (Get-Item $InputParameters.WorkingFolder -ErrorAction SilentlyContinue).PSProvider.Name -eq 'FileSystem') {
        $WorkingFolder = $InputParameters.WorkingFolder 
    }
    else {
        $WorkingFolder = "\\$($InputParameters.QisServerName)\QRM\WorkingFolder"
    }
    if ($InputParameters.DatabaseLocation) {
        $DatabaseLocation = $InputParameters.DatabaseLocation
    }
    else {
        $DatabaseLocation = 'C:\SQL\Data'
    }
    if ($InputParameters.LogLocation) {
        $LogLocation = $InputParameters.LogLocation
    }
    else {
        $LogLocation = 'C:\SQL\Log'
    }

    $SqlAdminPsCredential = New-Object System.Management.Automation.PSCredential ("$($InputParameters.DatabaseAdminUser)", (ConvertTo-SecureString $InputParameters.DatabaseAdminPassword -AsPlainText -Force -ErrorAction SilentlyContinue))
   
    #Add SQL record
    $DscProperties = @{
        Ensure                  = 'Present'
        AuthenticationMode      = $AuthenticationMode
        SqlCredential           = $SqlCredential
        CaSqlServerName         = $InputParameters.QrmSqlServer
        SqlServerName           = $InputParameters.QrmSqlServer
        WorkingFolder           = $WorkingFolder
        DatabaseLocation        = $DatabaseLocation
        LogLocation             = $LogLocation
        EscalationSqlCredential = $SqlAdminPsCredential
        CaUri                   = $CaUri
    }
    try {
        if ((Invoke-DscResource -Name QrmCaSqlServer -Method Test -ModuleName Qrm.Qis -Property $DscProperties -ErrorAction Stop).InDesiredState -eq $false) {
            Invoke-DscResource -Name QrmCaSqlServer -Method Set -ModuleName Qrm.Qis -Property $DscProperties -ErrorAction Stop
            if ((Invoke-DscResource -Name QrmCaSqlServer -Method Test -ModuleName Qrm.Qis -Property $DscProperties -ErrorAction Stop).InDesiredState -eq $false) {
                WriteLog -LogString "FAILED to create the SQL server record in CA. Please check the log for details."
            }
            else {
                WriteLog -LogString "CA SQL server record created successfully."
            }
        }
        else {
            WriteLog -LogString "CA SQL server record already exists."
        }
    }
    catch {
        WriteLog -LogString "Cannot create the CA SQL server record. Please check the log for details. $($_.Exception)"
    } 
    
    #Add OLAP server record
    $DscProperties = @{
        Ensure                   = 'Present'
        OlapServerInstanceId     = $InputParameters.OlapServerName
        Name                     = $InputParameters.OlapServerName
        SkipConnectionValidation = $true
        CaUri                    = $CaUri
    }
    try {
        if ((Invoke-DscResource -Name QrmCaOlapServer -Method Test -ModuleName Qrm.Qis -Property $DscProperties -ErrorAction Stop).InDesiredState -eq $false) {
            Invoke-DscResource -Name QrmCaOlapServer -Method Set -ModuleName Qrm.Qis -Property $DscProperties -ErrorAction Stop
            if ((Invoke-DscResource -Name QrmCaOlapServer -Method Test -ModuleName Qrm.Qis -Property $DscProperties -ErrorAction Stop).InDesiredState -eq $false) {
                WriteLog -LogString "FAILED to create the OLAP record in CA. Please check the log for details."
            }
            else {
                WriteLog -LogString "CA OLAP server record created successfully."
            }
        }
        else {
            WriteLog -LogString "CA OLAP server record already exists."
        }
    }
    catch {
        WriteLog -LogString "Cannot create the CA OLAP server record. Please check the log for details. $($_.Exception)"
    }
        
    #Add Reporting server record
    $DscProperties = @{
        Ensure                    = 'Present'
        ReportingServerInstanceId = $InputParameters.ReportingServerURI
        SkipConnectionValidation  = $true
        CaUri                     = $CaUri
    }
    try {
        if ((Invoke-DscResource -Name QrmCaRsServer -Method Test -ModuleName Qrm.Qis -Property $DscProperties -ErrorAction Stop).InDesiredState -eq $false) {
            Invoke-DscResource -Name QrmCaRsServer -Method Set -ModuleName Qrm.Qis -Property $DscProperties -ErrorAction Stop
            if ((Invoke-DscResource -Name QrmCaRsServer -Method Test -ModuleName Qrm.Qis -Property $DscProperties -ErrorAction Stop).InDesiredState -eq $false) {
                WriteLog -LogString "FAILED to create the RS record in CA. Please, check log for details."
            }
            else {
                WriteLog -LogString "CA SSRS server record created successfully."
            }
        }
        else {
            WriteLog -LogString "CA SSRS server record already exists."
        }
    }
    catch {
        WriteLog -LogString "Cannot create SSRS server record. Please check the log for details. $($_.Exception)"
    }
    #Add Database
    if ((Get-QrmCaSqlDatabase -CaSqlDatabaseName $InputParameters.FrameworkCaDatabaseName -CaUri $CaUri -ErrorAction SilentlyContinue)) {
        WriteLog -LogString "Framework database $($InputParameters.FrameworkCaDatabaseName) already exists."
    }
    else {
        try {
            WriteLog -LogString "Configuring Framework database $($InputParameters.FrameworkCaDatabaseName)."
            New-QrmCaSqlDatabase -CaSqlDatabaseName $InputParameters.FrameworkCaDatabaseName -DefaultAccess "FullAccess" -ApplicationType $InputParameters.ApplicationType -EnvironmentType $InputParameters.EnvironmentType -OlapServerInstanceId $InputParameters.OlapServerName -ReportingServerInstanceId $InputParameters.ReportingServerURI -CaUri $CaUri -ErrorAction Stop | Out-Null
            if ($InputParameters.FrameworkDatabasePhysicalName) {
                Set-QrmCaSqlDatabase -CaSqlDatabaseName $InputParameters.FrameworkCaDatabaseName -SqlServerName $InputParameters.QrmSqlServer -PhysicalSqlDatabaseName $InputParameters.FrameworkDatabasePhysicalName -CaUri $CaUri -ErrorAction Stop -Confirm:$false | Out-Null
                WriteLog -LogString "Physical database $($InputParameters.FrameworkDatabasePhysicalName) attach. SUCCESS."
            }
            else {
                WriteLog -LogString "The physical Framework database name was not provided."
            }
        }
        catch {
            WriteLog -LogString "Failed to add Framework database $($InputParameters.FrameworkCaDatabaseName). $($_.Exception)"
        }
    }  
    #Add HPC Server Configuration
    if ((Get-QrmCaHpcServerConfiguration -CaUri $CaUri -ErrorAction SilentlyContinue).HpcHeadNode -eq $InputParameters.HpcHeadNodeName) {
        WriteLog -LogString "CA HPC integration is already configured."
    }
    else {
        try {
            WriteLog -LogString "Configuring CA HPC integration configuration $($InputParameters.HpcHeadNodeName)."
            Set-QrmCaHpcServerConfiguration -HpcHeadNode $InputParameters.HpcHeadNodeName -CaUri $CaUri -HpcDefaultJobTemplate $InputParameters.DefaultJobTemplateName -ErrorAction Stop -Confirm:$false | Out-Null
            $RunAsCredential = New-Object System.Management.Automation.PSCredential ("$($InputParameters.QisServiceUser)@$($InputParameters.DomainDnsName)", (ConvertTo-SecureString $InputParameters.QisServicePassword -AsPlainText -Force -ErrorAction Continue))
            Set-QrmCaDistributedJobCredentials -RunAsCredential $RunAsCredential -CaUri $CaUri -Confirm:$false -ErrorAction Stop 
            WriteLog -LogString "Successfully configured CA HPC integration configuration $($InputParameters.HpcHeadNodeName)."
        }
        catch {
            WriteLog -LogString "Failed to add CA HPC integration configuration $($InputParameters.HpcHeadNodeName). $($_.Exception)"
        }
    }

    #Add Granular Job Template Assignment for ETL
    try {
        WriteLog -LogString  "Configuring granular template mapping." 
        if ((Get-QrmCaHpcTemplateMapping -CaUri $CaUri | Where-Object TaskTypeId -EQ 'ETL')) {
            WriteLog -LogString "The ETL HPC template mapping already exists." 
        }
        else {
            New-QrmCaHpcTemplateMapping -CaUri $CaUri -DisplayName 'ETL Jobs' -TaskTypeId 'ETL' -JobTemplate $InputParameters.EtlJobTemplateName -ErrorAction Stop | Out-Null
            WriteLog -LogString "Successfully created ETL HPC template mapping."
        }

        if ((Get-QrmCaHpcTemplateMapping -CaUri $CaUri | Where-Object TaskTypeId -EQ 'ETL (Multithreaded)')) {
            WriteLog -LogString "The ETL (Multithreaded) HPC template mapping already exists." 
        }
        else {
            New-QrmCaHpcTemplateMapping -CaUri $CaUri -DisplayName 'ETL (Multithreaded)' -TaskTypeId 'ETL (Multithreaded)' -JobTemplate $InputParameters.EtlJobTemplateName -ErrorAction Stop | Out-Null
            WriteLog -LogString "Successfully created ETL (Multithreaded) HPC template mapping."
        }

        if ((Get-QrmCaHpcTemplateMapping -CaUri $CaUri | Where-Object TaskTypeId -EQ 'ETL - 64 Bit')) {
            WriteLog -LogString "The 'ETL - 64 Bit' HPC template mapping already exists." 
        }
        else {
            New-QrmCaHpcTemplateMapping -CaUri $CaUri -DisplayName 'ETL - 64 Bit' -TaskTypeId 'ETL - 64 Bit' -JobTemplate $InputParameters.EtlJobTemplateName -ErrorAction Stop | Out-Null
            WriteLog -LogString "Successfully created 'ETL - 64 Bit' HPC template mapping."
        }

        if ((Get-QrmCaHpcTemplateMapping -CaUri $CaUri | Where-Object TaskTypeId -EQ 'ETL (Multithreaded) - 64 Bit')) {
            WriteLog -LogString "The 'ETL (Multithreaded) - 64 Bit' HPC template mapping already exists." 
        }
        else {
            New-QrmCaHpcTemplateMapping -CaUri $CaUri -DisplayName 'ETL (Multithreaded) - 64 Bit' -TaskTypeId 'ETL (Multithreaded) - 64 Bit' -JobTemplate $InputParameters.EtlJobTemplateName -ErrorAction Stop | Out-Null
            WriteLog -LogString "Successfully created ETL (Multithreaded) - 64 Bit HPC template mapping."
        }
    }
    catch {
        WriteLog -LogString "Failed to add HPC template mapping. $($_.Exception)"
    }
        
    #Add Email Server
    if ($InputParameters.SmtpServerName -and (Get-QrmCaEmailServer -CaUri $CaUri).SmtpServer -ne $InputParameters.SmtpServerName) {        
        try {
            WriteLog -LogString "Configuring Email server $($InputParameters.SmtpServerName)." 
            Set-QrmCaEmailServer -CaUri $CaUri -SmtpServer $InputParameters.SmtpServerName -SenderEmailAddress $InputParameters.SenderEmailAddress -ErrorAction Stop -Confirm:$false | Out-Null
        }
        catch {
            WriteLog -LogString "Failed to add Email server $($InputParameters.SmtpServerName). $($_.Exception)"
        }
    }
    else {
        WriteLog -LogString "Skipping Email server configuration SmtpServerName =  $($InputParameters.SmtpServerName)."
    }
        
    #Add User group to CA
    try {
        WriteLog -LogString "Setting up QRM users $($InputParameters.QrmUsersGroup)."
        if (!(Get-QrmCaUser -CaUri $CaUri -UserName $InputParameters.QrmUsersGroup -ErrorAction SilentlyContinue)) { 
            New-QrmCaUser -CaUri $CaUri -UserName $InputParameters.QrmUsersGroup -UserRoles $InputParameters.QrmUserGroupRoles -FrameworkLoginApplication $InputParameters.QrmUserGroupFrameworkLoginRights -PcpLoginApplication $InputParameters.QrmUserGroupPcpLoginRights -ScriptingLoginApplication $InputParameters.QrmUserGroupScriptingLoginRights -ErrorAction Stop | Out-Null
        }
        else {
            WriteLog -LogString "QIS Users $($InputParameters.QrmUsersGroup) already exists." 
        }
    }
    catch {
        WriteLog -LogString "Failed to add QRM users $($InputParameters.QrmUsersGroup). $($_.Exception)"
    }
        
    #Add administrators to CA
    try {
        WriteLog -LogString "Configuring QIS administrators $($InputParameters.QrmAdminsGroup)." 
        $FrameworkAppList = @("CA", "WCS", "DI", "MR", "AL", "MB", "IP", "CP")
        $LoginAppList = @("AL", "MB", "MR")
        if (!(Get-QrmCaUser -CaUri $CaUri -UserName $InputParameters.QrmAdminsGroup -ErrorAction SilentlyContinue)) {
            New-QrmCaUser -CaUri $CaUri -UserName $InputParameters.QrmAdminsGroup -UserRoles 'SystemAdmin' -FrameworkLoginApplication $FrameworkAppList -ScriptingLoginApplication $LoginAppList -PcpLoginApplication $LoginAppList  -ErrorAction Stop | Out-Null
        }
        else {
            WriteLog -LogString "QIS administrators $($InputParameters.QrmAdminsGroup) already exists."
        } 
    }
    catch {
        WriteLog -LogString "Failed to add QIS administrators $($InputParameters.QrmAdminsGroup). $($_.Exception)"
    }
        
    #Add license
    try {
        WriteLog -LogString "Configuring License." 
        if (!$InputParameters.LicenseFile) {
            WriteLog -LogString "License File not provided. Skipping License setup." 
        }
        else {
            $DscProperties = @{
                Ensure        = 'Present'
                LicenseIdName = $InputParameters.LicenseName
                LicenseFile   = $InputParameters.LicenseFile
                CaUri         = $CaUri
            }
            try {
                if ((Invoke-DscResource -Name QrmCaLicense -Method Test -ModuleName Qrm.Qis -Property $DscProperties -ErrorAction Stop).InDesiredState -eq $false) {
                    Invoke-DscResource -Name QrmCaLicense -Method Set -ModuleName Qrm.Qis -Property $DscProperties -ErrorAction Stop
                    if ((Invoke-DscResource -Name QrmCaLicense -Method Test -ModuleName Qrm.Qis -Property $DscProperties -ErrorAction Stop).InDesiredState -eq $false) {
                        WriteLog -LogString "FAILED to add license to CA. Please, check log for details."
                    }
                    else {
                        WriteLog -LogString "Successfully added license to CA."
                    }
                }
                else {
                    WriteLog -LogString "License already exists."
                }
            }
            catch {
                WriteLog -LogString "Cannot add license to CA. Please check the log for details. $($_.Exception)"
            }
        }
    }
    catch {
        WriteLog -LogString "Failed to configure License. $($_.Exception)"
    }
}
function ConfigureMsdtc {
    try {
        if (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSDTC" -Name "ServerTcpPort" -ErrorAction SilentlyContinue) {
            Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSDTC" -Name "ServerTcpPort" -Value "5001" -ErrorAction Stop
        }
        else {
            New-ItemProperty -Name "ServerTcpPort" -PropertyType Dword -Value "5001" -Path "HKLM:\SOFTWARE\Microsoft\MSDTC" -ErrorAction Stop
        }
        Set-ItemProperty -Name "NetworkDtcAccess" -Value "1" -Path "HKLM:\SOFTWARE\Microsoft\MSDTC\Security" -ErrorAction Stop
        Set-ItemProperty -Name "NetworkDtcAccessInbound" -Value "1" -Path "HKLM:\SOFTWARE\Microsoft\MSDTC\Security" -ErrorAction Stop
        Set-ItemProperty -Name "NetworkDtcAccessOutbound" -Value "1" -Path "HKLM:\SOFTWARE\Microsoft\MSDTC\Security" -ErrorAction Stop
        Set-ItemProperty -Name "NetworkDtcAccessTransactions" -Value "1" -Path "HKLM:\SOFTWARE\Microsoft\MSDTC\Security" -ErrorAction Stop
        Set-ItemProperty -Name "Start" -Value "2" -Path "HKLM:\SYSTEM\CurrentControlSet\Services\MSDTC" -ErrorAction Stop
        Set-ItemProperty -Name "DelayedAutostart" -Value "1" -Path "HKLM:\SYSTEM\CurrentControlSet\Services\MSDTC" -ErrorAction Stop
        Restart-Service -Name MSDTC -ErrorAction Stop
        WriteLog -LogString "Successfully configured MSDTC"
    }
    catch {
        WriteLog -LogString "Failed to Configure MSDTC. $($_.Exception)"
    }
}
function InstallSSSRS {
    param ([string] $InstallerFile)

    try {
        $ArgumentList = "/quiet /norestart /IAcceptLicenseTerms"
        $InstallResult = Start-Process -FilePath $InstallerFile -ArgumentList $ArgumentList -Wait -PassThru -ErrorAction Stop
        WriteLog -LogString "Succeeded Installing SSRS"
    }
    catch {
        WriteLog -LogString "Failed to Install SSRS(errCode=$($InstallResult.ExitCode))"
    }
}
function InstallReportViewer {
    param ([string] $InstallFolder)
    $InstallerFile = FindSetupFile -Path $InstallFolder -Extension exe -FileNameStartsWith 'ReportViewer'
    if (Get-Item -Path $InstallerFile -ErrorAction SilentlyContinue -ErrorVariable Err) {
        try {
            $ArgumentList = "/q"
            $InstallResult = Start-Process -FilePath $InstallerFile -ArgumentList $ArgumentList -Wait -PassThru -ErrorAction Stop
            WriteLog -LogString "Succeeded Installing ReportViewer"
        }
        catch {
            WriteLog -LogString "Failed to Install ReportViewer (errCode=$($InstallResult.ExitCode))"
        }
    }
    else {
        WriteLog -LogString "Skipping ReportViewer installation. File $InstallerFile is not present. $Err"
    }
}
function InstallAccessDatabaseEngine {
    param ([string] $InstallFolder)

    try {
        $InstallerFile = FindSetupFile -Path $InstallFolder -Extension exe -FileNameStartsWith 'AccessDatabaseEngine2016_x64'
        $ArgumentList = "/q"
        $InstallResult = Start-Process -FilePath $InstallerFile -ArgumentList $ArgumentList -Wait -PassThru -ErrorAction Stop
        WriteLog -LogString "Succeeded Installing Access Database Engine"
    }
    catch {
        WriteLog -LogString "Failed to Install Access Database Engine (errCode=$($InstallResult.ExitCode))"
    }
}
function InstallSqlAsoledb {
    param ([string] $InstallFolder)
    
    try {
        $InstallerFile = FindSetupFile -Path $InstallFolder -Extension msi -FileNameStartsWith 'x64_15.0.1800.100 _SQL_AS_OLEDB'
        $ArgumentList = '/quiet /i "' + $InstallerFile + '"'
        $InstallResult = Start-Process -FilePath "msiexec" -ArgumentList $ArgumentList -Wait -PassThru -ErrorAction Stop
        WriteLog -LogString "Succeeded installing SQL AS OLEDB"
    }
    catch {
        WriteLog -LogString "Failed to install SQL AS OLEDB (errCode=$($InstallResult.ExitCode))"
    }
}
function InstallSqlOledb {
    param ([string] $InstallFolder)
    
    try {
        $InstallerFile = FindSetupFile -Path $InstallFolder -Extension msi -FileNameStartsWith 'msoledbsql'
        $ArgumentList = '/quiet /i "' + $InstallerFile + '" IACCEPTMSOLEDBSQLLICENSETERMS=YES'
        $InstallResult = Start-Process -FilePath "msiexec" -ArgumentList $ArgumentList -Wait -PassThru -ErrorAction Stop
        WriteLog -LogString "Succeeded installing SQL OLEDB"
    }
    catch {
        WriteLog -LogString "Failed to install SQL OLEDB (errCode=$($InstallResult.ExitCode))"
    }
}
function InstallFramework {
    param ([string] $InstallFolder,
        [string] $Application = 'AL', #MR,MB,AL
        [string] $InstallationLocation = 'C:\QRM\BSMFramework',
        [string] $CaServerName
    )
    if ($Application -eq 'AL') {
        $InstallerFile = FindSetupFile -Path $InstallFolder -Extension msi -FileNameStartsWith 'QRM Enterprise Risk Framework'
        $InstallerArguments = "INSTALLLOCATION=`"$InstallationLocation`" REGISTERAGAINSCA=`"$CaServerName`" ADDLOCAL=`"FrameworkApplicationFiles,ClientComponents`""        
    }
    if ($Application -eq 'MB') {
        $InstallerFile = FindSetupFile -Path $InstallFolder -Extension msi -FileNameStartsWith 'QRM Mortgage Banking'
        $InstallerArguments = "INSTALLLOCATION=`"$InstallationLocation`" REGISTERAGAINSCA=`"$CaServerName`" ADDLOCAL=`"FrameworkApplicationFiles,ClientComponents`"" 
    }
    if ($Application -eq 'MR') {
        $InstallerFile = FindSetupFile -Path $InstallFolder -Extension msi -FileNameStartsWith 'QRM Management Repository'
        $InstallerArguments = "INSTALLLOCATION=`"$InstallationLocation`" REGISTERAGAINSCA=`"$CaServerName`" ADDLOCAL=`"ProductFeature,WorkstationInstall`""  
    }    
    $ArgumentList = "/quiet /i `"$InstallerFile`" $InstallerArguments"
    WriteLog -LogString "Installation arguments: $ArgumentList"
    $InstallResult = Start-Process -FilePath "msiexec" -ArgumentList $ArgumentList -Wait -PassThru
    if ($InstallResult.ExitCode -eq 0) {
        WriteLog -LogString "Succeeded installing Framework"
    }
    else {
        WriteLog -LogString "Failed to install Framework (errCode=$($InstallResult.ExitCode))"
    }
    return $InstallResult.ExitCode
}
function CreateApplicationShortcut {
    param ([string] $ApplicationPath,
        [string] $ShortcutName
    )

    try {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut("C:\ProgramData\Microsoft\Windows\Start Menu\Programs\" + $ShortcutName + ".lnk")
        $shortcut.TargetPath = $ApplicationPath
        $shortcut.Save()
        WriteLog -LogString "Succeeded creating the Framework shortcut"
    }
    catch {
        WriteLog -LogString "Failed to create Framework shortcut (errCode=$($InstallResult.ExitCode))"
    }
}
function SetupNetworkShare {
    param (
        [string] $ShareName,
        [string] $LocalPath,
        [string] $UserGroup,
        [string] $AdminGroup,
        [string] $ServiceAccount  
    )
    $ACL = Get-ACL -Path $LocalPath
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($AdminGroup, "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($UserGroup, "Modify, Synchronize", "ContainerInherit, ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($ServiceAccount, "Modify, Synchronize", "ContainerInherit, ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $ACL | Set-Acl -Path $LocalPath
    $CurrentAccess = (Get-ACL -Path $LocalPath).Access
    WriteLog -LogString "Local Folder Access rights. $CurrentAccess"
    if (!(Get-SmbShare -Name $ShareName -ErrorAction SilentlyContinue)) {
        try {
            $Result = New-SmbShare -Name $ShareName -Path $LocalPath -ChangeAccess @($ServiceAccount, $UserGroup) -FullAccess $AdminGroup -ErrorAction Stop
            WriteLog -LogString "Successfully created $ShareName SMB file share. $Result"
        }
        catch {
            WriteLog -LogString "Failed to create $ShareName SMB file share. $($_.Exception)"
        }
    } 
    else {
        WriteLog -LogString "The $ShareName SMB file share already exists."
    }
}
function SetupFolderPermissions {
    param (
        [string] $LocalPath,
        [string] $AccountName  
    )
    $ACL = Get-ACL -Path $LocalPath
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($AccountName, "Modify, Synchronize", "ContainerInherit, ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $ACL | Set-Acl -Path $LocalPath
    $CurrentAccess = (Get-ACL -Path $LocalPath).Access
    WriteLog -LogString "Local Folder $LocalPath access rights. $($CurrentAccess | ConvertTo-csv)"
}
function InstallFptp {
} 
function RunSqlQuery {
    param ( 
        [string] $Query,
        [pscredential] $SqlCredential,
        [string] $SqlDatabase = 'TempDB',
        [string] $SqlServerName,
        [switch] $WindowsAuthentication
    )
    $NewSqlConnection = New-Object System.Data.SqlClient.SqlConnection
    $NewSqlConnection.ConnectionString = "Initial Catalog=$SqlDatabase;Data Source=$SqlServerName;Integrated Security=$WindowsAuthentication"        

    if (!$WindowsAuthentication) {
        $SqlCredential.Password.MakeReadOnly()
        $NewSqlConnection.Credential = New-Object System.Data.SqlClient.SqlCredential($SqlCredential.UserName, $SqlCredential.Password)
    }    
    try {
        $NewSqlConnection.Open()
    }
    catch {
        WriteLog -LogString "Cannot connect to the SQL Server $SqlServerName. $($_.Exception.gettype().FullName) $($_.Exception.Message)"
        return $false
    }
    $SqlCommand = New-Object System.Data.SqlClient.SqlCommand($Query , $NewSqlConnection)
    $SqlDataAdapter = New-Object System.Data.SqlClient.SqlDataAdapter $SqlCommand
    $SqlData = New-Object System.Data.DataSet
    try {
        $Output = $SqlDataAdapter.Fill($SqlData)
        WriteLog -LogString "SqlDataAdapter output: $Output"
    }
    catch {
        WriteLog -LogString "Failed to run SQL query. $($_.Exception.gettype().FullName) $($_.Exception.Message)"
        $NewSqlConnection.Close()
        return $false
    }
    $NewSqlConnection.Close()
    return $SqlData #$DataSet.Tables[0]
}
function RunSqlCommand {
    param ( 
        [string] $Query,
        [string] $SqlDatabase = 'master',
        [string] $SqlServerName = 'localhost',
        [switch] $SqlAuthentication,
        [pscredential] $SqlCredential
    )

    $UserName = $SqlCredential.GetNetworkCredential().username
    $Password = $SqlCredential.GetNetworkCredential().password

    try {
        if ($SqlAuthentication) {
            invoke-sqlcmd -Query $Query -ServerInstance $SqlServerName -querytimeout 0 -Username $UserName -Password $Password 
        }
        else {
            invoke-sqlcmd -Query $Query -ServerInstance $SqlServerName -querytimeout 0 
        }        
        WriteLog -LogString "RunSqlCommand output: $Output"
    }
    catch {
        WriteLog -LogString "Failed to run SQL command. $($_.Exception.gettype().FullName) $($_.Exception.Message)"
        return $false
    }
}
function ConfigureAwsRdsInstance {
    param (
        [PSObject] $InputParameters
    )
    $SqlAdminPsCredential = New-Object System.Management.Automation.PSCredential ("$($InputParameters.DatabaseAdminUser)", (ConvertTo-SecureString $InputParameters.DatabaseAdminPassword -AsPlainText -Force -ErrorAction Continue))
    
    $Query = "USE master`n
    If not Exists (select * from syslogins where name = `'$($InputParameters.QrmSqlUser)`')`n
    BEGIN`n
    CREATE LOGIN $($InputParameters.QrmSqlUser) WITH Password = `'$($InputParameters.QrmSqlPassword)`', DEFAULT_DATABASE=master, CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF`n
    GRANT VIEW SERVER STATE TO [$($InputParameters.QrmSqlUser)]`n
    GRANT CREATE ANY DATABASE TO [$($InputParameters.QrmSqlUser)]`n
    END`n"    
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query
    WriteLog -LogString "Creating SQL account for QRM databases. Status = $Result"

    #Create CA database
    $Query = "USE master`n
    IF NOT EXISTS(SELECT NAME FROM SYS.DATABASES WHERE NAME =`'$($InputParameters.QisCaDb)`')`n
    BEGIN`n
    CREATE DATABASE [$($InputParameters.QisCaDb)]`n
    ALTER DATABASE $($InputParameters.QisCaDb) SET RECOVERY SIMPLE`n
    ALTER DATABASE $($InputParameters.QisCaDb) MODIFY FILE (NAME=$($InputParameters.QisCaDb), NEWNAME=DATA_FILE,SIZE=1024MB,FILEGROWTH=1024MB)`n
    ALTER DATABASE $($InputParameters.QisCaDb) MODIFY FILE (NAME=$($InputParameters.QisCaDb)_log, NEWNAME=LOG_FILE,SIZE=1024MB,FILEGROWTH=1024MB)`n
    END`n"
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query
    WriteLog -LogString "Creating $($InputParameters.QisCaDb) database. Status = $Result"
    
    $Query = "USE [$($InputParameters.QisCaDb)]`n
    IF NOT EXISTS (SELECT * FROM [$($InputParameters.QisCaDb)].[sys].[database_principals] WHERE name = N`'$($InputParameters.QrmSqlUser)`') CREATE USER [$($InputParameters.QrmSqlUser)] FOR LOGIN [$($InputParameters.QrmSqlUser)]`n
    ALTER ROLE [db_owner] ADD MEMBER [$($InputParameters.QrmSqlUser)]`n
    USE master`n"
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query
    WriteLog -LogString "Adding Sql User to $($InputParameters.QisCaDb) database. Status = $Result" 
    
    #Create WCS database
    $Query = "USE master`n
    IF NOT EXISTS(SELECT NAME FROM SYS.DATABASES WHERE NAME =`'$($InputParameters.QisWcsDb)`')`n
    BEGIN`n
    CREATE DATABASE [$($InputParameters.QisWcsDb)]`n
    ALTER DATABASE $($InputParameters.QisWcsDb) SET RECOVERY SIMPLE`n
    ALTER DATABASE $($InputParameters.QisWcsDb) MODIFY FILE (NAME=$($InputParameters.QisWcsDb), NEWNAME=DATA_FILE,SIZE=1024MB,FILEGROWTH=1024MB)`n
    ALTER DATABASE $($InputParameters.QisWcsDb) MODIFY FILE (NAME=$($InputParameters.QisWcsDb)_log, NEWNAME=LOG_FILE,SIZE=1024MB,FILEGROWTH=1024MB)`n
    END`n" 
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query
    WriteLog -LogString "Creating $($InputParameters.QisWcsDb) database. Status = $Result"
    $Query = "USE [$($InputParameters.QisWcsDb)]`n
    IF NOT EXISTS (SELECT * FROM [$($InputParameters.QisWcsDb)].[sys].[database_principals] WHERE name = N`'$($InputParameters.QrmSqlUser)`') CREATE USER [$($InputParameters.QrmSqlUser)] FOR LOGIN [$($InputParameters.QrmSqlUser)]`n
    ALTER ROLE [db_owner] ADD MEMBER [$($InputParameters.QrmSqlUser)]`n
    USE master`n"
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query
    WriteLog -LogString "Adding Sql User to $($InputParameters.QisWcsDb) database. Status = $Result" 
}
function ConfigureSqlServerInstance {
    param (
        [PSObject] $InputParameters,
        [bool] $WindowsAuthenticationType = $false
    )
    $SqlAdminPsCredential = New-Object System.Management.Automation.PSCredential ("$($InputParameters.DatabaseAdminUser)", (ConvertTo-SecureString $InputParameters.DatabaseAdminPassword -AsPlainText -Force -ErrorAction Continue))

    $Query = "USE master`n
    EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode', REG_DWORD, 2"    
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query -WindowsAuthentication:$WindowsAuthenticationType
    WriteLog -LogString "Enable SQL Authentication. Status = $Result"
    Restart-Service -Name MSSQLSERVER -Force
    
    $Query = "USE master`n
    If not Exists (select * from syslogins where name = `'$($InputParameters.DatabaseAdminUser)`')`n
    BEGIN`n
    CREATE LOGIN $($InputParameters.DatabaseAdminUser) WITH Password = `'$($InputParameters.DatabaseAdminPassword)`', DEFAULT_DATABASE=master, CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF`n
    ALTER SERVER ROLE [sysadmin] ADD MEMBER [$($InputParameters.DatabaseAdminUser)]`n
    END`n"    
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query -WindowsAuthentication:$WindowsAuthenticationType
    WriteLog -LogString "Creating SQL admin account for QRM databases. Status = $Result"

    $Query = "USE master`n
    If not Exists (select * from syslogins where name = `'$($InputParameters.QrmSqlUser)`')`n
    BEGIN`n
    CREATE LOGIN $($InputParameters.QrmSqlUser) WITH Password = `'$($InputParameters.QrmSqlPassword)`', DEFAULT_DATABASE=master, CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF`n
    GRANT VIEW SERVER STATE TO [$($InputParameters.QrmSqlUser)]`n
    ALTER SERVER ROLE [bulkadmin] ADD MEMBER [$($InputParameters.QrmSqlUser)]`n
    ALTER SERVER ROLE [diskadmin] ADD MEMBER [$($InputParameters.QrmSqlUser)]`n
    ALTER SERVER ROLE [dbcreator] ADD MEMBER [$($InputParameters.QrmSqlUser)]`n
    END`n"    
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query -WindowsAuthentication:$WindowsAuthenticationType
    WriteLog -LogString "Creating SQL account for QRM databases. Status = $Result"

    #Create CA database
    $Query = "USE master`n
    IF NOT EXISTS(SELECT NAME FROM SYS.DATABASES WHERE NAME =`'$($InputParameters.QisCaDb)`')`n
    BEGIN`n
    CREATE DATABASE [$($InputParameters.QisCaDb)]`n
    ALTER DATABASE $($InputParameters.QisCaDb) SET RECOVERY SIMPLE`n
    ALTER DATABASE $($InputParameters.QisCaDb) MODIFY FILE (NAME=$($InputParameters.QisCaDb), NEWNAME=DATA_FILE,SIZE=1024MB,FILEGROWTH=1024MB)`n
    ALTER DATABASE $($InputParameters.QisCaDb) MODIFY FILE (NAME=$($InputParameters.QisCaDb)_log, NEWNAME=LOG_FILE,SIZE=1024MB,FILEGROWTH=1024MB)`n
    END`n"
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query -WindowsAuthentication:$WindowsAuthenticationType
    WriteLog -LogString "Creating $($InputParameters.QisCaDb) database. Status = $Result"
    
    $Query = "USE [$($InputParameters.QisCaDb)]`n
    IF NOT EXISTS (SELECT * FROM [$($InputParameters.QisCaDb)].[sys].[database_principals] WHERE name = N`'$($InputParameters.QrmSqlUser)`') CREATE USER [$($InputParameters.QrmSqlUser)] FOR LOGIN [$($InputParameters.QrmSqlUser)]`n
    ALTER ROLE [db_owner] ADD MEMBER [$($InputParameters.QrmSqlUser)]`n
    USE master`n"
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query -WindowsAuthentication:$WindowsAuthenticationType
    WriteLog -LogString "Adding Sql User to $($InputParameters.QisCaDb) database. Status = $Result" 
    
    #Create WCS database
    $Query = "USE master`n
    IF NOT EXISTS(SELECT NAME FROM SYS.DATABASES WHERE NAME =`'$($InputParameters.QisWcsDb)`')`n
    BEGIN`n
    CREATE DATABASE [$($InputParameters.QisWcsDb)]`n
    ALTER DATABASE $($InputParameters.QisWcsDb) SET RECOVERY SIMPLE`n
    ALTER DATABASE $($InputParameters.QisWcsDb) MODIFY FILE (NAME=$($InputParameters.QisWcsDb), NEWNAME=DATA_FILE,SIZE=1024MB,FILEGROWTH=1024MB)`n
    ALTER DATABASE $($InputParameters.QisWcsDb) MODIFY FILE (NAME=$($InputParameters.QisWcsDb)_log, NEWNAME=LOG_FILE,SIZE=1024MB,FILEGROWTH=1024MB)`n
    END`n" 
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query -WindowsAuthentication:$WindowsAuthenticationType
    WriteLog -LogString "Creating $($InputParameters.QisWcsDb) database. Status = $Result"
    $Query = "USE [$($InputParameters.QisWcsDb)]`n
    IF NOT EXISTS (SELECT * FROM [$($InputParameters.QisWcsDb)].[sys].[database_principals] WHERE name = N`'$($InputParameters.QrmSqlUser)`') CREATE USER [$($InputParameters.QrmSqlUser)] FOR LOGIN [$($InputParameters.QrmSqlUser)]`n
    ALTER ROLE [db_owner] ADD MEMBER [$($InputParameters.QrmSqlUser)]`n
    USE master`n"
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query -WindowsAuthentication:$WindowsAuthenticationType
    WriteLog -LogString "Adding Sql User to $($InputParameters.QisWcsDb) database. Status = $Result" 
}
function AddSAWindowsUserToSqlServerInstance {
    param (
        [PSObject] $InputParameters,
        [string] $DomainAccount,
        [bool] $WindowsAuthenticationType = $false
    )
    $SqlAdminPsCredential = New-Object System.Management.Automation.PSCredential ("$($InputParameters.DatabaseAdminUser)", (ConvertTo-SecureString $InputParameters.DatabaseAdminPassword -AsPlainText -Force -ErrorAction Continue))

    $Query = "USE master`n
    If not Exists (select * from syslogins where name = `'$($DomainAccount)`')`n
    BEGIN`n
    CREATE LOGIN [$($DomainAccount)] FROM WINDOWS WITH DEFAULT_DATABASE=[master] `n
    END`n
    ALTER SERVER ROLE [sysadmin] ADD MEMBER [$($DomainAccount)]`n"    
    $Result = RunSqlQuery -SqlServerName $SqlServer -Query $Query -SqlCredential $SqlAdminPsCredential -WindowsAuthentication:$WindowsAuthenticationType
    WriteLog -LogString "Creating SQL admin account $DomainAccount. Status = $Result"
}
function ConfigureWindowsAuthenticationForFrameworkDatabase {
    param (
        [PSObject] $SqlServer,
        [string] $DomainAccount,
        [string] $DatabaseName
    )
    
    <#$Query = "USE master`n
    EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode', REG_DWORD, 2"    
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query -WindowsAuthentication
    WriteLog -LogString "Enable SQL Authentication. Status = $Result"
    Restart-Service -Name MSSQLSERVER -Force #>

    $Query = "USE master`n
    If not Exists (select * from syslogins where name = `'$($DomainAccount)`')`n
    BEGIN`n
    CREATE LOGIN [$($DomainAccount)] FROM WINDOWS WITH DEFAULT_DATABASE=[master] `n
    GRANT VIEW SERVER STATE TO [$($DomainAccount)]`n
    ALTER SERVER ROLE [bulkadmin] ADD MEMBER [$($DomainAccount)]`n
    ALTER SERVER ROLE [diskadmin] ADD MEMBER [$($DomainAccount)]`n
    ALTER SERVER ROLE [dbcreator] ADD MEMBER [$($DomainAccount)]`n
    END`n"    
    $Result = RunSqlQuery -SqlServerName $SqlServer -Query $Query -WindowsAuthentication
    WriteLog -LogString "Creating SQL account $DomainAccount for QRM database $DatabaseName. Status = $Result"
    
    $Query = "USE [$($DatabaseName)]`n
    IF NOT EXISTS (SELECT * FROM [$($DatabaseName)].[sys].[database_principals] WHERE name = N`'$($DomainAccount)`') CREATE USER [$($DomainAccount)] FOR LOGIN [$($DomainAccount)]`n
    ALTER ROLE [db_owner] ADD MEMBER [$($DomainAccount)]`n
    USE master`n"
    $Result = RunSqlQuery -SqlServerName $SqlServer -Query $Query -WindowsAuthentication
    WriteLog -LogString "Adding $DomainAccount to $($InputParameters.QisCaDb) database. Status = $Result" 
}
function RestoreAwsDatabase {
    param (
        [string] $DestinationBucket,
        [string] $FrameworkDatabaseBackupFile,
        [string] $FrameworkDatabasePhysicalName,
        [pscredential] $SqlAdminPsCredential,
        [string] $SqlServerName,
        [string] $QrmSqlUserName
    )

    try {
        $InstanceDocument = (Invoke-RestMethod -Method Get -Uri http://169.254.169.254/latest/dynamic/instance-identity/document -ErrorAction Stop)         
        WriteLog -LogString "This instance region is $($InstanceDocument.region)."
    }
    catch {
        WriteLog -LogString "Failed to get instance region. $($_.Exception)"
    }
    try {
        Write-S3Object -BucketName $DestinationBucket -Key "$($FrameworkDatabasePhysicalName).bak" -File $FrameworkDatabaseBackupFile -Region $InstanceDocument.region -ErrorAction Stop          
        WriteLog -LogString "Framework database backup $FrameworkDatabaseBackupFile copy success."
    }
    catch {
        WriteLog -LogString "Failed to copy Framework database backup. $($_.Exception)"
    }

    $Query = "exec msdb.dbo.rds_restore_database @restore_db_name='$FrameworkDatabasePhysicalName', @s3_arn_to_restore_from='arn:aws:s3:::$($DestinationBucket)/$($FrameworkDatabasePhysicalName).bak'"
    WriteLog -LogString "Restoring database: $Query"
    $Result = RunSqlQuery -Query $Query -SqlCredential $SqlAdminPsCredential -SqlServerName $SqlServerName
    WriteLog -LogString "Restoring database: $($FrameworkDatabasePhysicalName) database. Task ID = $($Result.Tables[0].task_id). Status = $($Result.Tables[0].lifecycle)"

    $TaskId = $Result.Tables[0].task_id 
    $StartDate = Get-Date
    $TimeOutminutes = 30
    $RetryIntervalSeconds = 60
    $Query = "exec msdb.dbo.rds_task_status @task_id='$TaskId'"
    WriteLog -LogString "Starting database restore status. $Query" 
    do {               
        $Result = RunSqlQuery -Query $Query -SqlCredential $SqlAdminPsCredential -SqlServerName $SqlServerName
        WriteLog -LogString "Database restore status = $($Result.Tables[0].'% complete') % complete"
        if ($Result.Tables[0].lifecycle -eq "SUCCESS") {
            WriteLog -LogString "Database $($FrameworkDatabasePhysicalName) restored successfully. $($Result.Tables[0].task_info)" 
            break 
        }
        if ($Result.Tables[0].lifecycle -eq "ERROR") {
            WriteLog -LogString "Failed to restore Database $($FrameworkDatabasePhysicalName). $($Result.Tables[0].task_info)"  
            break 
        }
        Start-Sleep -Seconds $RetryIntervalSeconds

    } while ($StartDate.AddMinutes($TimeOutminutes) -gt (Get-Date))
    WriteLog -LogString "Restore TAsk ID = $TaskId.  Status = $($Result.Tables[0].lifecycle). Info = $($Result.Tables[0].task_info)"  
    if ($Result.Tables[0].lifecycle -eq "SUCCESS") {    
        $Query = "USE [$($FrameworkDatabasePhysicalName)]`n
    IF NOT EXISTS (SELECT * FROM [$($FrameworkDatabasePhysicalName)].[sys].[database_principals] WHERE name = N`'$($QrmSqlUserName)`') CREATE USER [$($QrmSqlUserName)] FOR LOGIN [$($QrmSqlUserName)]`n
    ALTER ROLE [db_owner] ADD MEMBER [$($QrmSqlUserName)]`n
    USE master`n"
        WriteLog -LogString "Setting Up permissions: $Query"
        $Result = RunSqlQuery -Query $Query -SqlCredential $SqlAdminPsCredential -SqlServerName $SqlServerName
        WriteLog -LogString "Adding Sql User $QrmSqlUserName to $($FrameworkDatabasePhysicalName) database = $($Result)"
    } 
}
function RestoreSqlDatabase {
    param (
        [PSObject] $InputParameters,
        [string] $FrameworkDatabaseBackupFile,
        [bool] $WindowsAuthenticationType = $false
    )
    $SqlAdminPsCredential = New-Object System.Management.Automation.PSCredential ("$($InputParameters.DatabaseAdminUser)", (ConvertTo-SecureString $InputParameters.DatabaseAdminPassword -AsPlainText -Force -ErrorAction Continue))

    $Query = "USE master`n
    IF NOT EXISTS(SELECT NAME FROM SYS.DATABASES WHERE NAME =`'$($InputParameters.FrameworkDatabasePhysicalName)`')`n
    BEGIN`n
    CREATE DATABASE [$($InputParameters.FrameworkDatabasePhysicalName)]`n
    ALTER DATABASE $($InputParameters.FrameworkDatabasePhysicalName) SET RECOVERY SIMPLE`n
    ALTER DATABASE $($InputParameters.FrameworkDatabasePhysicalName) MODIFY FILE (NAME=$($InputParameters.FrameworkDatabasePhysicalName), NEWNAME=DATA_FILE,SIZE=1024MB,FILEGROWTH=1024MB)`n
    ALTER DATABASE $($InputParameters.FrameworkDatabasePhysicalName) MODIFY FILE (NAME=$($InputParameters.FrameworkDatabasePhysicalName)_log, NEWNAME=LOG_FILE,SIZE=1024MB,FILEGROWTH=1024MB)`n
    END`n" 
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query -WindowsAuthentication:$WindowsAuthenticationType
    WriteLog -LogString "Creating $($InputParameters.FrameworkDatabasePhysicalName) database. Status = $Result"
    $Query = "USE [$($InputParameters.FrameworkDatabasePhysicalName)]`n
    IF NOT EXISTS (SELECT * FROM [$($InputParameters.FrameworkDatabasePhysicalName)].[sys].[database_principals] WHERE name = N`'$($InputParameters.QrmSqlUser)`') CREATE USER [$($InputParameters.QrmSqlUser)] FOR LOGIN [$($InputParameters.QrmSqlUser)]`n
    ALTER ROLE [db_owner] ADD MEMBER [$($InputParameters.QrmSqlUser)]`n
    USE master`n"
    $Result = RunSqlQuery -SqlServerName $InputParameters.QrmSqlServer -SqlCredential $SqlAdminPsCredential -Query $Query -WindowsAuthentication:$WindowsAuthenticationType
    WriteLog -LogString "Adding Sql User to $($InputParameters.FrameworkDatabasePhysicalName) database. Status = $Result" 

    $MdfFile = Join-Path -Path $InputParameters.DatabaseLocation -ChildPath "$($InputParameters.FrameworkDatabasePhysicalName).mdf"
    $LdfFile = Join-Path -Path $InputParameters.LogLocation -ChildPath "$($InputParameters.FrameworkDatabasePhysicalName).ldf"
    $FrameworkDatabaseBackupFile = Join-Path -Path $InstallerSourcePath -ChildPath $InputParameters.FrameworkDatabaseBackUpFile
 
    $Query = "RESTORE DATABASE $($InputParameters.FrameworkDatabasePhysicalName) FROM  DISK = '$($FrameworkDatabaseBackupFile)' WITH  REPLACE,  MOVE '1_DATAFILE' TO '$MdfFile`',  MOVE '2_TRANSLOG' TO '$LdfFile`'"
    WriteLog -LogString "Restoring SQL database: $Query"
    $Result = RunSqlCommand -Query $Query -SqlCredential $SqlAdminPsCredential -SqlAuthentication:(!$WindowsAuthenticationType)
    WriteLog -LogString "Restoring SQL database: $($InputParameters.FrameworkDatabasePhysicalName) database."
}
function ConfigureSqlTempDb {
    param (
        [string] $Path
    )
    if ((Test-Path -Path $Path -ErrorAction SilentlyContinue)) {    
        $Query = "SELECT `'ALTER DATABASE tempdb MODIFY FILE (NAME = [`' + f.name + `'],`' + `' FILENAME = `'`'$($Path.TrimEnd('\'))\`' + f.name + CASE WHEN f.type = 1 THEN `'.ldf`' ELSE `'.mdf`' END	+ `'`'`');`' FROM sys.master_files f WHERE f.database_id = DB_ID(N`'tempdb`')"
        WriteLog -LogString "BUILD tempdb location query: $Query"
        $Result = RunSqlCommand -Query $Query
        $Query = ""
        foreach ($Record in $Result) {
            $Query = $Query + $Record.Column1
        }
        WriteLog -LogString "SET tempdb location: $Query"
        $Result = RunSqlCommand -Query $Query
        WriteLog -LogString "CHANGE location for tempdb files to $Path. $Result"
        Restart-Service -Name MSSQLSERVER -Force
    }
    else {
        WriteLog -LogString "Folder $Path does not exist. SKIP tempdb configuration."  
    }
}
function ConfigureWindowsFirewall {
    try {
        Set-NetFirewallProfile -Profile Domain, Public, Private -Enabled False -ErrorAction Stop
        WriteLog -LogString "Successfully configured Windows Firewall" 
    }
    catch {
        WriteLog -LogString "Failed to configure Windows Firewall. $($_.Exception)"
    }
}
function ConfigureNicPowerManagement {
    try {
        (Get-NetAdapterPowerManagement -ErrorAction Stop | Where-Object { $_.AllowComputerToTurnOffDevice -eq "Enabled" }) | Disable-NetAdapterPowerManagement -Name { $_.Name } -ErrorAction Stop
        WriteLog -LogString "Successfully configured NIC Power Management" 
    }
    catch {
        WriteLog -LogString "Failed to configure NIC Power Management. $($_.Exception)"
    }
}
function ConfigureHighPerformancePowerManagement {
    try {
        PowerCfg.exe /s 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
        WriteLog -LogString "Successfully configured Power Management" 
    }
    catch {
        WriteLog -LogString "Failed to configure Power Management. $($_.Exception)"
    }
}
function ConfigureIeesc {
    try {
        $AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
        $UserKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
        Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0 -Force -ErrorAction Stop
        Remove-ItemProperty -Path $UserKey -Name "IsInstalled" -Force -ErrorAction Stop
        Rundll32 iesetup.dll, IEHardenLMSettings
        Rundll32 iesetup.dll, IEHardenUser
        Rundll32 iesetup.dll, IEHardenAdmin
        WriteLog -LogString "Successfully configured IE Enhanced Security" 
    }
    catch {
        WriteLog -LogString "Failed to configure IE Enhanced Security. $($_.Exception)"
    }
}
function GetSsrsConfiguration {
    return Get-WmiObject -Namespace "root\Microsoft\SqlServer\ReportServer\RS_SSRS\v15\Admin" -class MSReportServer_ConfigurationSetting -ComputerName localhost
}
Function ConfigureSsrs {
    # Allow importing of sqlps module
    Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force

    # Retrieve the current configuration
    $RsConfiguration = GetSsrsConfiguration

    If (! $RsConfiguration.IsInitialized) {
        # Get the ReportServer and ReportServerTempDB creation script
        [string]$DatabaseScript = $RsConfiguration.GenerateDatabaseCreationScript("ReportServer", 1033, $false).Script

        # Import the SQL Server PowerShell module
        $SqlpsImport = $false
        try {
            Import-Module sqlps -DisableNameChecking -ErrorAction Stop | Out-Null
            $SqlConnection = New-Object Microsoft.SqlServer.Management.Common.ServerConnection -ArgumentList $env:ComputerName
            WriteLog -LogString "Successfully imported the sqlps PowerShell module" 
            $SqlpsImport = $true
        }
        catch {
            WriteLog -LogString "Failed to import the sqlps PowerShell module. $($_.Exception)"
        }

        if ($SqlpsImport) {
            # Establish a connection to the database server (localhost)
            $SqlConnection.ApplicationName = "SSRS Configuration Script"
            $SqlConnection.StatementTimeout = 0
            $SqlConnection.Connect()
            $SqlSmo = New-Object Microsoft.SqlServer.Management.Smo.Server -ArgumentList $SqlConnection

            # Create the ReportServer and ReportServerTempDB databases
            $SqlDatabase = $SqlSmo.Databases["master"]
            $SqlDatabase.ExecuteNonQuery($DatabaseScript)

            # Set permissions for the databases
            $DatabaseScript = $RsConfiguration.GenerateDatabaseRightsScript($RsConfiguration.WindowsServiceIdentityConfigured, "ReportServer", $false, $true).Script
            $SqlDatabase.ExecuteNonQuery($DatabaseScript)

            # Set the database connection info
            $RsConfiguration.SetDatabaseConnection("(local)", "ReportServer", 2, "", "")

            $RsConfiguration.SetVirtualDirectory("ReportServerWebService", "ReportServer", 1033)
            $RsConfiguration.ReserveURL("ReportServerWebService", "http://+:80", 1033)

            # For SSRS 2016-2017 only, older versions have a different name
            $RsConfiguration.SetVirtualDirectory("ReportServerWebApp", "Reports", 1033)
            $RsConfiguration.ReserveURL("ReportServerWebApp", "http://+:80", 1033)

            $RsConfiguration.InitializeReportServer($RsConfiguration.InstallationID)

            # Restart services
            $RsConfiguration.SetServiceState($false, $false, $false)
            Restart-Service $RsConfiguration.ServiceName
            $RsConfiguration.SetServiceState($true, $true, $true)

            # Update the current configuration
            $RsConfiguration = GetSsrsConfiguration

            $RsVerify = Get-WmiObject -Namespace "root\Microsoft\SqlServer\ReportServer\RS_SSRS\v15" -class MSReportServer_Instance -ComputerName localhost
            $RsVerify.GetReportServerUrls()
            
            # Warm up RS service
            Invoke-WebRequest -URI "https://localhost/reports" -UseDefaultCredentials

            WriteLog -LogString "Successfully configured SSRS"
        }
    }
}
function AddSsrsPermissions {
    Param (
        [Parameter(Mandatory = $false)] [string] $Path = '/',
        [Parameter(Mandatory = $true)] [string] $Identity,
        [Parameter(Mandatory = $false)] [string] $RoleName = 'Content Manager')
        
    $InheritsParentPolicy = $false
    $ReportServerUri = 'http://localhost/ReportServer/ReportService2010.asmx'
    $RetryCount = 2
    $Completed = $false
    $Count = 1

    while (!$Completed) {
        if ($Count -le $RetryCount) {
            try {
                $Proxy = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential -ErrorAction Stop
                $OriginalPolicies = $Proxy.GetPolicies($Path, [ref]$InheritsParentPolicy)

                # Check for the identity in the existing permissions
                if (($OriginalPolicies | Where-Object { $_.GroupUserName -eq $Identity }).Roles.Name -contains $RoleName) {
                    if ($Strict) {
                        WriteLog -LogString "$($Identity) already has $($RoleName) privileges"
                    }
                    else {
                        WriteLog -LogString "$($Identity) already has $($RoleName) privileges"
                        return
                    }
                }

                $Namespace = $Proxy.GetType().Namespace
                $PolicyDataType = $Namespace + '.Policy'
                $RoleDataType = $Namespace + '.Role'
        
                $NumPolicies = $OriginalPolicies.Length + 1
                $Policies = New-Object -TypeName "$PolicyDataType[]" -ArgumentList $NumPolicies
                $index = 0

                foreach ($OriginalPolicy in $OriginalPolicies) {
                    $Policies[$index++] = $OriginalPolicy
                }

                $Policy = New-Object -TypeName $PolicyDataType
                $Policy.GroupUserName = $Identity
                $Role = New-Object -TypeName $RoleDataType
                $Role.Name = $RoleName
                $NumRoles = 1
                $Policy.Roles = New-Object -TypeName "$RoleDataType[]" -ArgumentList $NumRoles
                $Policy.Roles[0] = $Role
                $Policies[$OriginalPolicies.Length] = $Policy
                $Proxy.SetPolicies($Path, $Policies)

                WriteLog -LogString "Successfully added SSRS permissions: $($Identity)"
                $Completed = $true
            }
            catch {
                WriteLog -LogString "Failed to add SSRS permissions: $($Identity). $($_.Exception)"
                $Completed = $false
                $RetryCount = $RetryCount++
            }
        }
        else {
            $Completed = $true
        }
        $Count++
    }
}
Function AddSsasPermissions {
    param(
        [Parameter(Mandatory = $True, ValueFromPipeline)]
        [string] $Identity,
        [string] $Instance = "."
    )
    
    try {
        [Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices")
        $Server = New-Object Microsoft.AnalysisServices.Server
        $Server.Connect($Instance)
        $Administrators = $Server.Roles["Administrators"]

        if ($Administrators.Members.Name -notcontains $Identity) {
            $Administrators.Members.Add($Identity) | Out-Null
            $Administrators.Update()
        }
        $Server.Disconnect()
        WriteLog -LogString "Successfully added SSAS permissions: $($Identity)"
    }
    catch {
        WriteLog -LogString "Failed to add SSAS permissions: $($Identity). $($_.Exception)"
    }
}
function AddDomainAccountToDomainGroup {
    param (
        [string] $Account,
        [string] $Group,
        [Parameter(Mandatory = $true)] [ValidateSet('User', 'Computer')]
        [string] $Type,
        [PSCredential] $Credential
    )

    try {
        if ($Type -eq 'User') {
            $AccountMembers = Get-ADUser $Account -ErrorAction Stop
        }
        elseif ($Type -eq 'Computer') {
            $AccountMembers = Get-ADComputer $Account -ErrorAction Stop
        }
        Add-ADGroupMember -Identity $Group -Members $AccountMembers -Credential $Credential -ErrorAction Stop
        WriteLog -LogString "Successfully added account $Account to domain group $Group." 
    }
    catch {
        WriteLog -LogString "Failed to add account $Account to domain group $Group. $($_.Exception)"
        return $false 
    }
}
function Get-AwsSecret {
    param ([string] $AwsSecretName)
    $SecretsManager = Get-SECSecretValue -SecretId $AwsSecretName 
    $Secrets = $SecretsManager.SecretString | ConvertFrom-Json
    return $Secrets    
}
function Get-EnvironmentConfigurationParameters {
    param ([string] $ParametersFile)
    $Parameters = Import-PowerShellDataFile -Path $ParametersFile
    return $Parameters
}
function ConvertTfvarsTo-Psd1 {
    param ([string] $TerraformVariablesFile, [string] $ParametersFile)
    $KeyVaultParameters = 'DomainDnsName = ""
DomainNetBIOSName = ""
DatabaseAdminUser = ""
DatabaseAdminPassword = ""
QisServiceUser = ""
QisServicePassword = ""
QrmSqlUser = ""
QrmSqlPassword = ""
QrmUsersGroup = ""
QrmAdminsGroup = ""
DomainAdminUser = ""
MicrosoftADPassword = ""'
    $FileContent = Get-Content -Path $TerraformVariablesFile -Raw
    Set-Content -Path $ParametersFile -Value "@{$($FileContent)`n$($KeyVaultParameters)}" -Force    
}
function ImportCertificate {
    param ([string] $CertificateFile, [string] $CertificatePassword)    
    $CertPass = ConvertTo-SecureString $CertificatePassword -AsPlainText -Force
    $Certificate = Import-PfxCertificate -FilePath $CertificateFile -CertStoreLocation 'Cert:\LocalMachine\My' -Password $CertPass
    $Certificate = Import-PfxCertificate -FilePath $CertificateFile -CertStoreLocation 'Cert:\LocalMachine\Root' -Password $CertPass
    return $Certificate.Thumbprint
}
function CreateFolder {
    param (
        [string] $LocalPath = 'C:\QRM\WorkingFolder'
    )
    if (!(Test-Path -Path $LocalPath -ErrorAction SilentlyContinue)) {
        try {
            New-Item -Path $LocalPath -ItemType Directory -Force -ErrorAction Stop
            WriteLog -LogString "Successfully created directory $($LocalPath)"
        }
        catch {
            WriteLog -LogString "Failed to create directory $($LocalPath). $($_.Exception)"
        }
    }
    else {
        WriteLog -LogString "Directory $($LocalPath) already exists."
    }
}
function SetupMultidimensionalOlapMode {
    param (
        [string] $OlapServiceName = 'MSSQLServerOLAPService'
    )
    try {
        $OlapService = Get-WmiObject -Class Win32_Service -Filter "Name like '$OlapServiceName'" -ErrorAction Stop
        WriteLog -LogString "OLAP service command line. $($OlapService.PathName)"
        $OlapConfigPath = $OlapService.PathName.Split('"')[3]
        WriteLog -LogString "OLAP service config folder. $($OlapConfigPath)"
        $OlapConfigFile = Join-Path -Path $OlapConfigPath -ChildPath 'msmdsrv.ini' -ErrorAction Stop
        Test-Path -Path $OlapConfigFile -ErrorAction Stop
        WriteLog -LogString "OLAP service configuration file. $($OlapConfigFile)"
        [XML]$XMLcontent = Get-Content -Path $OlapConfigFile -ErrorAction Stop
        if ($XMLcontent.ConfigurationSettings.DeploymentMode -ne 0) {
            $OlapConfigFileBackup = Join-Path -Path $OlapConfigPath -ChildPath 'msmdsrv.ini.backup'
            Copy-Item -Path $OlapConfigFile -Destination $OlapConfigFileBackup -Force -ErrorAction Stop
            WriteLog -LogString "Created backup of OLAP service configuration file. $($OlapConfigFileBackup)"
            $XMLcontent.ConfigurationSettings.DeploymentMode = '0'
            $XMLcontent.Save($OlapConfigFile)
            Stop-Service -Name $OlapServiceName -Force -ErrorAction Stop
            Start-Service -Name $OlapServiceName -ErrorAction Stop
        }
        else {
            WriteLog -LogString "The OLAP server is already configured in multidimensional mode. DeploymentMode = $($XMLcontent.ConfigurationSettings.DeploymentMode)" 
        }      
    }
    catch {
        WriteLog -LogString "Failed to switch OLAP server mode. $($_.Exception)" 
    }
}
function SetCaRegistryKey {
    param (
        [string] $RegistryKey = 'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\QRM\CA',
        [string] $Property = 'CAServerLocation',
        [string] $Value = 'tcp://QIS01:1820'
    )
    if (!(Get-Item -Path $RegistryKey -ErrorAction SilentlyContinue)) {
        try {
            New-Item -Path $RegistryKey -Force -ErrorAction Stop
            WriteLog -LogString "Created registry key. $($RegistryKey)" 
        }
        catch {
            WriteLog -LogString "Failed to create the registry key. $($RegistryKey). $($_.Exception)"
        }
    }
    try {
        $RegistryKeyValue = (Get-ItemProperty -Path $RegistryKey -ErrorAction Stop | Select-Object -Property $Property)."$Property"
        if ($RegistryKeyValue -ne $Value) {
            New-ItemProperty -Path $RegistryKey -Name $Property -Value $Value -Force -ErrorAction Stop
            WriteLog -LogString "Successfully changed the value of the registry key Property $Property to $($Value)" 
        }
        else {
            WriteLog -LogString "The value of the registry key Property $Property is already set to $($RegistryKeyValue)" 
        } 
    }
    catch {
        WriteLog -LogString "Failed to change value of the registry key Property $Property. $($_.Exception)"
    }
}

########## Begin Script ###########

#Enable TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# *** All Servers Tasks ***

#Setup Log File
$Logfile = Join-Path -Path $InstallerSourcePath -ChildPath 'QrmInstallationConfiguration.log'
WriteLog -LogString "*** Starting Configuration. $(Get-Date) ***"
WriteLog -LogString "Process runs as $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)."

#Check if script runs As Administrator
if (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    WriteLog -LogString "Script is not running As Administrator. The process will now exit. Launch this script again with elevated privilages."
    Exit
}

#Read Parameters File
try {
    $ParametersFilePath = Join-Path -Path $InstallerSourcePath -ChildPath $ParametersFileName -ErrorAction Stop
    if ($TerraformVariablesFile) {
        ConvertTfvarsTo-Psd1 -TerraformVariablesFile $TerraformVariablesFile -ParametersFile $ParametersFilePath
    }
    $InputParameters = Get-EnvironmentConfigurationParameters -ParametersFile $ParametersFilePath
    WriteLog -LogString "Successfully read parameters file $ParametersFilePath." 
}
catch {
    WriteLog -LogString "Failed to read parameters file $ParametersFilePath. $($_.Exception)"
}

if ($CloudProvider -eq 'AWS' -or $CloudProvider -eq 'Azure') {
    if ($CloudProvider -eq 'AWS') {
        try {
            $EnvironmentConfig = Get-AwsSecret -AwsSecretName $AwsSecretName
            WriteLog -LogString "Successfully read AWS secrets"
        }
        catch {
            WriteLog -LogString "Failed to read AWS Secrets. $($_.Exception)"
        }
        $InputParameters.CertificatePassword = $EnvironmentConfig.CertificatePassword
    }
    if ($CloudProvider -eq 'Azure') {
        try {
            $EnvironmentConfig = Get-AzureSecret -AzureKeyVaultName $AzureKeyVaultName
            WriteLog -LogString "Successfully read Azure secrets"
        }
        catch {
            WriteLog -LogString "Failed to read Azure Secrets. $($_.Exception)"
        }
    }
    $InputParameters.DomainDnsName = $EnvironmentConfig.DomainDnsName
    $InputParameters.DomainNetBIOSName = $EnvironmentConfig.DomainNetBIOSName
    $InputParameters.DatabaseAdminUser = $EnvironmentConfig.DatabaseAdminUser
    $InputParameters.DatabaseAdminPassword = $EnvironmentConfig.DatabaseAdminPassword
    $InputParameters.QisServiceUser = $EnvironmentConfig.QisServiceUser
    $InputParameters.QisServicePassword = $EnvironmentConfig.QisServicePassword
    $InputParameters.QrmSqlUser = $EnvironmentConfig.QrmSqlUser
    $InputParameters.QrmSqlPassword = $EnvironmentConfig.QrmSqlPassword
    $InputParameters.QrmUsersGroup = $EnvironmentConfig.QrmUsersGroup
    $InputParameters.QrmAdminsGroup = $EnvironmentConfig.QrmAdminsGroup
    $InputParameters.DomainAdminUser = $EnvironmentConfig.DomainAdminUser 
    $InputParameters.MicrosoftADPassword = $EnvironmentConfig.MicrosoftADPassword
    #From Cloud foramtion some values are expected to come as coma separated values. We need to convert them into list
    $InputParameters.QrmUserGroupFrameworkLoginRights = $InputParameters.QrmUserGroupFrameworkLoginRights.split(',')
    $InputParameters.QrmUserGroupScriptingLoginRights = $InputParameters.QrmUserGroupScriptingLoginRights.split(',')
    $InputParameters.QrmUserGroupPcpLoginRights = $InputParameters.QrmUserGroupPcpLoginRights.split(',')
    $InputParameters.QrmUserGroupRoles = $InputParameters.QrmUserGroupRoles.split(',') 
}

#Check Scheduled task. Abort if exist.
if ($CreateScheduledTask -eq $true) {

    $Parameters = ""
    foreach ($ParentParameters in $PSBoundParameters.GetEnumerator()) {
        $Value = ''
        if ($ParentParameters.Value -is [system.array] ) {
            foreach ($val in $ParentParameters.Value) {
                $Value = $Value += "$Val,"
            }
            $Value = $Value.TrimEnd(',')
        } 
        else {
            $Value = $ParentParameters.Value     
        }
        $Parameters = $Parameters + "-$($ParentParameters.Key) $Value "
    }
    CreateScheduledTask -TaskName 'ConfigureQrmServer' -TaskArguments "-ExecutionPolicy Bypass -WindowStyle Hidden -NoProfile -Command C:\QrmInstaller\QrmEnvironmentInstallationConfiguration.ps1 $Parameters" -AtSystemStartup
}

#In Azure we import certificate from keyvault during deployment. So we are going to skip certificate import.
if ($CloudProvider -ne 'Azure') {

    #Import HPC Certificate
    try {
        $HPCCertificateFile = Join-Path -Path $InstallerSourcePath -ChildPath $InputParameters.HpcCertificateFileName -ErrorAction Stop
        $HpcCertificateThumbprint = ImportCertificate -CertificateFile $HpcCertificateFile -CertificatePassword $InputParameters.CertificatePassword
        $InputParameters.HpcCertificateThumbprint = $HpcCertificateThumbprint
        WriteLog -LogString "Successfully imported HPC certificate $HpcCertificateThumbprint." 
    }
    catch {
        WriteLog -LogString "Failed to import HPC certificate $HpcCertificateThumbprint. $($_.Exception)"
    }

    #Import QIS Certificate
    try {
        $QisCertificateFile = Join-Path -Path $InstallerSourcePath -ChildPath $InputParameters.QisCertificateFileName -ErrorAction Stop
        $QisCertificateThumbprint = ImportCertificate -CertificateFile $QisCertificateFile -CertificatePassword $InputParameters.CertificatePassword
        $InputParameters.QisCertificateThumbprint = $QisCertificateThumbprint
        WriteLog -LogString "Successfully imported QIS certificate $QisCertificateThumbprint." 
    }
    catch {
        WriteLog -LogString "Failed to import QIS certificate $QisCertificateThumbprint. $($_.Exception)"
    }
}

if ($SqlInstanceName) {
    $InputParameters.QrmSqlServer = $SqlInstanceName
}
if ($QisServerName) {
    $InputParameters.QisServerName = $QisServerName
}
if ($HpcHeadNodeName) {
    $InputParameters.HpcHeadNodeName = $HpcHeadNodeName
}

#Extract installer
$HpcPackInstallationSource = Join-Path -Path $InstallerSourcePath -ChildPath 'HPCPackInstall'
$QrmInstallationSource = Join-Path -Path $InstallerSourcePath -ChildPath 'QrmInstaller'
ExtractQrmInstallationFiles -ArchiveFile "$InstallerSourcePath\$($InputParameters.QrmInstaller)" -DestinationFolder $QrmInstallationSource
ExtractZipArchive -ArchiveFile "$InstallerSourcePath\$($InputParameters.HpcInstaller)" -DestinationFolder $HpcPackInstallationSource

#Install .Net
InstallDotNet -DotNetInstaller "$QrmInstallationSource\Redistributables\ndp48-x86-x64-allos-enu.exe"

# *** End All Servers Tasks ***

if ($ServerRole -Contains 'Sql') {
    if ($CloudProvider -eq 'AWS') {
        foreach ($Path in (Get-Disk).Path) {
            $Disk = GetAwsServerDrive -Path $Path
            if (!$Disk.DriveLetter) { 
                $LocalPath = $null
                switch ($Disk.Device) {
                    'xvdf' { $LocalPath = $InputParameters.DatabaseLocation } #SQL data drive
                    'xvdg' { $LocalPath = $InputParameters.LogLocation } #SQL log drive
                    'xvdh' { $LocalPath = $InputParameters.TempDbLocation } #SQL tempDB drive
                    'xvdi' { $LocalPath = $InputParameters.OlapDataLocation } #SQL OLAP data drive 
                }
                SetServerDrive -Disk $Disk -FolderPath $LocalPath
                SetupFolderPermissions -LocalPath $LocalPath -AccountName 'Everyone'
            }
        }
        #Change Tempdb location
        ConfigureSqlTempDb -Path $InputParameters.TempDbLocation
        ConfigureSqlServerInstance -InputParameters $InputParameters -WindowsAuthenticationType $true
    }
    if ($CloudProvider -eq 'Azure') {
        ConfigureSqlServerInstance -InputParameters $InputParameters -WindowsAuthenticationType $false
        AddSAWindowsUserToSqlServerInstance -InputParameters $InputParameters -WindowsAuthenticationType $false -DomainAccount 'NT AUTHORITY\SYSTEM'
        #AddSAWindowsUserToSqlServerInstance -InputParameters $InputParameters -WindowsAuthenticationType $false -DomainAccount "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmSqlServer)`$"
    }
    
    #$FrameworkDatabaseBackupFile = Join-Path -Path $InstallerSourcePath -ChildPath $InputParameters.FrameworkDatabaseBackUpFile
    RestoreSqlDatabase -InputParameters $InputParameters -FrameworkDatabaseBackupFile $InputParameters.FrameworkDatabaseBackUpFile
    if ($InputParameters.AuthenticationMode -eq 'Windows') {
        ConfigureWindowsAuthenticationForFrameworkDatabase -SqlServer $InputParameters.QrmSqlServer -DomainAccount "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServerName)`$" -DatabaseName $InputParameters.QisCaDb
        ConfigureWindowsAuthenticationForFrameworkDatabase -SqlServer $InputParameters.QrmSqlServer -DomainAccount "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServerName)`$" -DatabaseName $InputParameters.QisWcsDb
        ConfigureWindowsAuthenticationForFrameworkDatabase -SqlServer $InputParameters.QrmSqlServer -DomainAccount "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser)" -DatabaseName $InputParameters.QisCaDb
        ConfigureWindowsAuthenticationForFrameworkDatabase -SqlServer $InputParameters.QrmSqlServer -DomainAccount "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser)" -DatabaseName $InputParameters.QisWcsDb
        ConfigureWindowsAuthenticationForFrameworkDatabase -SqlServer $InputParameters.QrmSqlServer -DomainAccount "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser)" -DatabaseName $InputParameters.FrameworkDatabasePhysicalName
        ConfigureWindowsAuthenticationForFrameworkDatabase -SqlServer $InputParameters.QrmSqlServer -DomainAccount "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup)" -DatabaseName $InputParameters.QisCaDb
        ConfigureWindowsAuthenticationForFrameworkDatabase -SqlServer $InputParameters.QrmSqlServer -DomainAccount "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup)" -DatabaseName $InputParameters.QisWcsDb
        ConfigureWindowsAuthenticationForFrameworkDatabase -SqlServer $InputParameters.QrmSqlServer -DomainAccount "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup)" -DatabaseName $InputParameters.FrameworkDatabasePhysicalName
    }
    #Configure Server Tuning
    ConfigureWindowsFirewall
    ConfigureNicPowerManagement
    ConfigureHighPerformancePowerManagement
    ConfigureMsdtc   
}
if ($ServerRole -Contains 'HpcHeadNode') {
    #Install AD PS tools
    WriteLog -LogString "Starting Installation of Remote Administration Tools"  
    Install-WindowsFeature -Name 'RSAT-Role-Tools' -ErrorAction Continue
    $AdminPsCredential = New-Object System.Management.Automation.PSCredential ("$($InputParameters.DomainNetBIOSName)\$($InputParameters.DomainAdminUser)", (ConvertTo-SecureString $InputParameters.MicrosoftADPassword -AsPlainText -Force -ErrorAction Continue))
    #Create QrmAdmin Group
    $Result = SetupADaccount -Identity $InputParameters.QrmAdminsGroup -Group -Credential $AdminPsCredential
    WriteLog -LogString "Creating Active Directory QRM Administrators group. Status = $Result"
    #Create QrmUsers Group
    $Result = SetupADaccount -Identity $InputParameters.QrmUsersGroup -Group -Credential $AdminPsCredential
    WriteLog -LogString "Creating Active Directory QRM Users group. Status = $Result"
    #Create QisService Account
    $Result = SetupADaccount -Identity $InputParameters.QisServiceUser -Password $InputParameters.QisServicePassword -Credential $AdminPsCredential
    WriteLog -LogString "Creating Active Directory Qis service account. Status = $Result"

    WriteLog "Starting Installation of HPC Pack Head Node"  
    $InstallResult = InstallHpcHeadNode -HpcPackInstallationSource $HpcPackInstallationSource -CertificateThumbprint $InputParameters.HpcCertificateThumbprint

    ConfigureHpcHeadNode -InputParameters $InputParameters
    CreateScheduledTask -TaskName 'ConfigureComputeNodes' -TaskArguments "-ExecutionPolicy Bypass -WindowStyle Hidden -NoProfile -File C:\QrmInstaller\QrmEnvironmentInstallationConfiguration.ps1 -CloudProvider $CloudProvider -SqlInstanceName $($InputParameters.QrmSqlServer)  -AwsSecretName `"$AwsSecretName`" -HpcHeadNodeName $($InputParameters.HpcHeadNodeName) -QisServerName $($InputParameters.QisServerName) -ServerRole AwsHpcComputeNode"

    #Configure Server Tuning
    ConfigureWindowsFirewall
    ConfigureNicPowerManagement
    ConfigureHighPerformancePowerManagement
    ConfigureMsdtc
    ConfigureIeesc
          
    if ($InstallResult.ExitCode -eq 3010) {
        WriteLog "Starting server reboot."
        Restart-Computer -Force
    }
}
if ($ServerRole -Contains 'HpcComputeNode') {
    WriteLog -LogString "Starting installation of HPC Compute Node"  
    $InstallResult = InstallHpcComputeNode -HpcHeadNodeName $InputParameters.HpcHeadNodeName -CertificateThumbprint $InputParameters.HpcCertificateThumbprint -HpcPackInstallationSource $HpcPackInstallationSource 
          
    if ($InstallResult.ExitCode -eq 3010) {
        WriteLog -LogString "Starting server reboot."
        Restart-Computer -Force
    }
    if ($CloudProvider -eq 'AWS') {
        Create_AWS_Ec2instance_ServerTag -HpcGroupTagValue $InputParameters.HpcComputeNodeGroup
    }

    #Configure Server Tuning
    ConfigureWindowsFirewall
    ConfigureNicPowerManagement
    ConfigureHighPerformancePowerManagement
    ConfigureMsdtc
    ConfigureIeesc
}
if ($ServerRole -Contains 'Qis') {
    #Install AD PS tools
    WriteLog -LogString "Starting installation of Remote Administration Tools"
    Install-WindowsFeature -Name 'RSAT-Role-Tools' -ErrorAction Continue
    $AdminPsCredential = New-Object System.Management.Automation.PSCredential ("$($InputParameters.DomainNetBIOSName)\$($InputParameters.DomainAdminUser)", (ConvertTo-SecureString $InputParameters.MicrosoftADPassword -AsPlainText -Force -ErrorAction Continue))
    #Create QrmAdmin Group
    $Result = SetupADaccount -Identity $InputParameters.QrmAdminsGroup -Group -Credential $AdminPsCredential
    WriteLog -LogString "Creating Active Directory QRM Administrators group. Status = $Result"
    #Create QrmUsers Group
    $Result = SetupADaccount -Identity $InputParameters.QrmUsersGroup -Group -Credential $AdminPsCredential
    WriteLog -LogString "Creating Active Directory QRM Users group. Status = $Result"
    #Create QisService Account
    $Result = SetupADaccount -Identity $InputParameters.QisServiceUser -Password $InputParameters.QisServicePassword  -Credential $AdminPsCredential
    WriteLog -LogString "Creating Active Directory Qis service account. Status = $Result"
    #Add Permissions
    if ($CloudProvider -eq 'AWS') {
        AddDomainAccountToDomainGroup -Account $InputParameters.DomainAdminUser -Group $InputParameters.QrmAdminsGroup -Type 'User' -Credential $AdminPsCredential
        AddDomainAccountToDomainGroup -Account $InputParameters.QrmSqlServer -Group $InputParameters.QrmUsersGroup -Type 'Computer' -Credential $AdminPsCredential
        AddDomainAccountToDomainGroup -Account $InputParameters.QisServerName -Group $InputParameters.QrmUsersGroup -Type 'Computer' -Credential $AdminPsCredential
        AddDomainAccountToDomainGroup -Account $InputParameters.QisServiceUser -Group $InputParameters.QrmUsersGroup -Type 'User' -Credential $AdminPsCredential
    }
    
    #Create Sql Account 
    if ($CloudProvider -eq 'AWS') {
        if ( $InputParameters.QrmSqlServer.EndsWith('rds.amazonaws.com')) {
            ConfigureAwsRdsInstance -InputParameters $InputParameters
            if (!([string]::IsNullOrEmpty($InputParameters.FrameworkDatabasePhysicalName))) {
                $SqlAdminPsCredential = New-Object System.Management.Automation.PSCredential ("$($InputParameters.DatabaseAdminUser)", (ConvertTo-SecureString $InputParameters.DatabaseAdminPassword -AsPlainText -Force -ErrorAction SilentlyContinue))
                #$FrameworkDatabaseBackupFile = Join-Path -Path $InstallerSourcePath -ChildPath $InputParameters.FrameworkDatabaseBackUpFile
                RestoreAwsDatabase -DestinationBucket $InputParameters.qrms3bucket -FrameworkDatabasePhysicalName $InputParameters.FrameworkDatabasePhysicalName -FrameworkDatabaseBackupFile $InputParameters.FrameworkDatabaseBackUpFile -SqlServerName $InputParameters.QrmSqlServer -QrmSqlUserName $InputParameters.QrmSqlUser -SqlAdminPsCredential $SqlAdminPsCredential
            }
        }
        if (([string]::IsNullOrEmpty($InputParameters.ReportingServerURI))) {
            $InputParameters.ReportingServerURI = "http://$($InputParameters.OlapServerName)/ReportServer"
        }        
    }
    if ($CloudProvider -eq 'Azure') {
        Copy-Item -Path "\\$($InputParameters.HpcHeadNodeName)\REMINST"  -Destination $HpcPackInstallationSource -Recurse -Force
    }

    #Install QIS
    WriteLog -LogString "Starting installation of QIS"
    InstallQis -InputParameters $InputParameters -QisInstallerPath $InstallerSourcePath -QisInstallType 1
    ConfigureQis -InputParameters $InputParameters
    
    #Configure Server Tuning
    ConfigureWindowsFirewall
    ConfigureNicPowerManagement
    ConfigureHighPerformancePowerManagement
    ConfigureIeesc
    ConfigureMsdtc

    #Install Prerequisites
    #InstallReportViewer -InstallFolder $InstallerSourcePath    
    InstallHpcClientTools -HpcPackInstallationSource $HpcPackInstallationSource
    if ($CloudProvider -eq 'Azure') {
        CreateScheduledTask -TaskName 'ConfigureAzureHpcCluster' -TaskArguments "-ExecutionPolicy Bypass -WindowStyle Hidden -NoProfile -File C:\QrmInstaller\QrmEnvironmentInstallationConfiguration.ps1 -CloudProvider $CloudProvider  -AzureKeyVaultName `"$AzureKeyVaultName`" -ServerRole AzureHpcConfigManager" -Credential $AdminPsCredential
    }

    #Create Network Share
    SetupNetworkShare -ShareName 'QRM' -LocalPath 'C:\QRM' -UserGroup "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup)" -AdminGroup "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmAdminsGroup)" -ServiceAccount "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QisServiceUser)"

    #Install Framework
    InstallFramework -InstallFolder $InstallerSourcePath -Application $InputParameters.ApplicationType -InstallationLocation "C:\QRM\$($InputParameters.ApplicationType)_Framework" -CaServerName $InputParameters.QisServerName

    #Create SQL Working Folder
    CreateFolder
}
if ($ServerRole -Contains 'Olap' ) {
    if ($CloudProvider -eq 'Azure') {
        $Disk = GetAzureServerDrive -DiskLun $InputParameters.OlapDiskLun
        SetServerDrive -Disk $Disk -FolderPath $InputParameters.OlapDataLocation
        SetupFolderPermissions -LocalPath $InputParameters.OlapDataLocation -AccountName 'Everyone'
        InstallSSSRS -InstallerFile "$($InstallerSourcePath)\SQLServerReportingServices.exe"
    }

    InstallQis -InputParameters $InputParameters -QisInstallerPath $InstallerSourcePath -QisInstallType 3

    #Configure Server Tuning
    ConfigureWindowsFirewall
    ConfigureNicPowerManagement
    ConfigureHighPerformancePowerManagement
    ConfigureMsdtc   
    ConfigureSsrs
    ConfigureIeesc
    SetupMultidimensionalOlapMode 
    SetupOlapDrives -FolderPath $InputParameters.OlapDataLocation
    AddSsrsPermissions -Identity "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmAdminsGroup)"
    AddSsrsPermissions -Identity "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup)"
    AddSsasPermissions -Identity "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmAdminsGroup)"
    AddSsasPermissions -Identity "$($InputParameters.DomainNetBIOSName)\$($InputParameters.QrmUsersGroup)"
}

if ($ServerRole -Contains 'EtlHpcComputeNode') {    
    if ($CloudProvider -eq 'AWS') {
        Create_AWS_Ec2instance_ServerTag -HpcGroupTagValue $InputParameters.HpcEtlNodeGroup
    }
    if ($CloudProvider -eq 'Azure') {
        Copy-Item -Path "\\$($InputParameters.HpcHeadNodeName)\REMINST"  -Destination $HpcPackInstallationSource -Recurse -Force
        #Set-ItemProperty -Path REGISTRY::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System -Name ConsentPromptBehaviorAdmin -Value 0
    }
    InstallHpcComputeNode -HpcHeadNodeName $InputParameters.HpcHeadNodeName -CertificateThumbprint $InputParameters.HpcCertificateThumbprint -HpcPackInstallationSource $HpcPackInstallationSource

    #Configure Server Tuning
    ConfigureWindowsFirewall
    ConfigureNicPowerManagement
    ConfigureHighPerformancePowerManagement
    ConfigureMsdtc
    ConfigureIeesc

    #Install Prerequisites
    InstallAccessDatabaseEngine -InstallFolder $InstallerSourcePath
    InstallSqlAsoledb -InstallFolder $InstallerSourcePath
    InstallSqlOledb -InstallFolder $InstallerSourcePath
}

if ($ServerRole -Contains 'Interface') {
    if ($CloudProvider -eq 'Azure') {
        Copy-Item -Path "\\$($InputParameters.HpcHeadNodeName)\REMINST"  -Destination $HpcPackInstallationSource -Recurse -Force
        #Set-ItemProperty -Path REGISTRY::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System -Name ConsentPromptBehaviorAdmin -Value 0
    }
    InstallHpcClientTools -HpcPackInstallationSource $HpcPackInstallationSource
    InstallQis -InputParameters $InputParameters -QisInstallerPath $InstallerSourcePath -QisInstallType 3

    #Configure Server Tuning
    ConfigureWindowsFirewall
    ConfigureNicPowerManagement
    ConfigureHighPerformancePowerManagement
    ConfigureMsdtc
    ConfigureIeesc

    #Install Prerequisites
    #InstallReportViewer -InstallFolder $InstallerSourcePath
    InstallSqlAsoledb -InstallFolder $InstallerSourcePath
    InstallSqlOledb -InstallFolder $InstallerSourcePath
    
    #set CA registry Key
    SetCaRegistryKey -Value "tcp://$($InputParameters.QisServerName):1820"

    #Create Application Shortcuts
    CreateApplicationShortcut -ApplicationPath "\\$($InputParameters.QisServerName)\QRM\AL_Framework\erfmain.exe" -ShortcutName "QRM Enterprise Risk Framework"
}

if ($ServerRole -Contains 'AwsHpcComputeNode') {
    ConfigureAwsHpcComputeNode -InputParameters $InputParameters

    #Configure Server Tuning
    ConfigureWindowsFirewall
    ConfigureNicPowerManagement
    ConfigureHighPerformancePowerManagement
    ConfigureMsdtc
    ConfigureIeesc
}

if ($ServerRole -Contains 'AzureHpcConfigManager') {
    ConfigureHpcHeadNode -InputParameters $InputParameters
    ConfigureHpcComputeNode -InputParameters $InputParameters -EtlComputeNodeName $InputParameters.OlapServerName
}
Disable-ScheduledTask -TaskName 'ConfigureQrmServer'